# MEHVAR

A professional e-commerce platform with a versioned REST catalog, a consistent error envelope, idempotent checkout, and field selection to stop over-fetching.

MEHVAR is the working answer to a classic marketplace problem: verb-based URIs (`/getProductsList`), raw 500s that crash mobile clients, duplicate orders on retry, and 50-field JSON payloads for a home-screen title and price.

## Problem

Legacy marketplace backends (the Daraz / Bazaar class of systems) tend to fail in four ways:

1. **Unstandardized URIs** — endpoints named after procedures instead of resources.
2. **Unhonest errors** — client mistakes surface as 500 Internal Server Error.
3. **Non-idempotent checkout** — a retried `POST /orders` creates a second order and a second stock deduction.
4. **Over-fetching** — a banner that needs `title` and `price` downloads description, vendor, and inventory metrics.

## What MEHVAR implements

| Module | Contract |
| --- | --- |
| REST resource model | Noun-based `/api/v1/products`, `/api/v1/categories`, `/api/v1/orders` with GET, POST, PUT, DELETE |
| Errors | `{ error_code, message, timestamp, path }` — 400 / 401 / 403 / 404 / 409 / 500, never a leaked stack |
| Pagination & filter | `?category=electronics&search=headphones&page=1&limit=5` |
| Field selection | `GET /api/v1/products/1?fields=title,price` — unknown fields → 400 `INVALID_FIELDS` |
| Idempotency | `Idempotency-Key` on `POST /api/v1/orders`. PUT product/order updates are naturally idempotent |
| Storefront | Catalog, search, cart, checkout, orders, Studio (admin) |

The first signed-in account on a fresh database is promoted to **ADMIN** so merchandising and fulfillment can be demonstrated immediately.

## Architecture

```
Browser (MEHVAR storefront)
        │  fetch /api/v1/*
        ▼
TanStack Start HTTP handlers   ←  same process, same contracts
        │
        ▼
Services  →  Postgres (Neon in production, embedded PGLite in preview)
```

Business logic lives in `src/server/*`. Route handlers validate, authorize, and map status codes. They do not talk to SQL directly.

### Data model

- **profiles** — `user_id` (text), `role` (`CUSTOMER` \| `ADMIN`)
- **categories** → **products**
- **orders** → **order_items** → **products**
- **idempotency_keys** — keyed ledger for order creation

Orders are scoped to the verified session user. Admin reads are the exception, enforced server-side.

## REST surface

Base path: `/api/v1`

| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| GET | `/products` | public | filter, search, pagination, `fields` |
| GET | `/products/{id}` | public | `?fields=title,price` |
| POST | `/products` | admin | 201 Created + Location |
| PUT | `/products/{id}` | admin | Idempotent full replace |
| DELETE | `/products/{id}` | admin | 204, 409 if referenced by orders |
| GET/POST | `/categories` | POST admin | |
| PUT/DELETE | `/categories/{id}` | admin | |
| GET/POST | `/orders` | session | POST accepts `Idempotency-Key` |
| GET/PUT | `/orders/{id}` | session / admin | PUT updates status |
| GET | `/inventory` | admin | stock table |
| GET | `/auth/me` | session | `{ id, email, role }` |

Interactive console: **`/docs`**.

### Error example

```json
{
  "error_code": "PRODUCT_NOT_FOUND",
  "message": "Product with ID 123 was not found.",
  "timestamp": "2026-09-22T21:30:00.000Z",
  "path": "/api/v1/products/123"
}
```

### Idempotency

`POST /api/v1/orders` with header `Idempotency-Key: <8–128 chars>`:

- Same key + same body + same user → original `201` payload is replayed. Stock is not deducted again.
- Same key + different body → `409 IDEMPOTENCY_KEY_CONFLICT`.
- PUT product / PUT order status write the full intended state, so repeating the call cannot diverge.

### Over-fetching

`GET /api/v1/products/1?fields=title,price` returns only those keys. The product page has a **Bandwidth mode** toggle that uses this contract live.

## Storefront

- `/` editorial home
- `/products` catalog, category chips, search, pagination
- `/products/{id}` product detail + field-selection demo
- `/cart` `/checkout` `/orders` `/orders/{id}`
- `/login` `/register` — email/password plus Google and X
- `/admin` Studio — products, orders, inventory
- `/docs` live REST console

## Stack

React 19, TanStack Start / Router / Query, Tailwind v4, Zod, Better Auth, Postgres.

## Tests

Covered in `src/server/fields.test.ts`:

1. Field selection parsing
2. Unknown fields → 400
3. Empty `fields` → 400
4. Projection of requested keys only
5. Error envelope shape
6. Pagination defaults and math
7. Oversized `limit` → 400
8. Stable idempotency hashing (key order and user isolation)

Live HTTP checks (create 201, get 200, missing 404, invalid 400, PUT 200, DELETE 204, filter, pagination, field selection, duplicate Idempotency-Key) can be run from `/docs`.

## License

Portfolio / university project. Catalog photography via Unsplash.
