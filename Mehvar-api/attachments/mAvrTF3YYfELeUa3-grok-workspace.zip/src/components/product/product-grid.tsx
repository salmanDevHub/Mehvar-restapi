import type { Product } from "@/lib/types";
import { ProductCard } from "./product-card";

export function ProductGrid({ products }: { products: Product[] }) {
  if (products.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-border-strong bg-surface px-6 py-16 text-center">
        <p className="font-display text-2xl">Nothing in this aisle</p>
        <p className="mt-2 text-sm text-muted">Try another category, or clear the search.</p>
      </div>
    );
  }
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}

export function ProductGridSkeleton() {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="overflow-hidden rounded-xl bg-surface ring-1 ring-border">
          <div className="aspect-[4/5] animate-pulse bg-bg-2" />
          <div className="space-y-2 p-4">
            <div className="h-3 w-16 animate-pulse rounded bg-bg-2" />
            <div className="h-5 w-3/4 animate-pulse rounded bg-bg-2" />
            <div className="h-4 w-20 animate-pulse rounded bg-bg-2" />
          </div>
        </div>
      ))}
    </div>
  );
}
