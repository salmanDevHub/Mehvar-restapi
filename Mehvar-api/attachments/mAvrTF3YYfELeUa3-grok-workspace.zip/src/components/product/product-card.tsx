import { Link } from "@tanstack/react-router";
import { formatMoney } from "@/lib/utils";
import type { Product } from "@/lib/types";

export function ProductCard({ product }: { product: Product }) {
  const soldOut = product.stock <= 0;
  return (
    <Link
      to="/products/$id"
      params={{ id: String(product.id) }}
      className="group flex flex-col overflow-hidden rounded-xl bg-surface shadow-[0_18px_40px_-28px_rgb(23_20_17_/_0.45)] ring-1 ring-border transition-transform duration-200 hover:-translate-y-0.5"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-bg-2">
        <img
          src={product.image_url}
          alt={product.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
        />
        {soldOut && (
          <span className="absolute left-3 top-3 rounded-full bg-ink/85 px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] text-bg">
            Sold out
          </span>
        )}
        {product.featured && !soldOut && (
          <span className="absolute left-3 top-3 rounded-full bg-surface/90 px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] text-ink">
            Featured
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col p-4">
        <p className="text-[11px] uppercase tracking-[0.16em] text-faint">{product.brand || product.category}</p>
        <h3 className="mt-1 font-display text-lg leading-snug tracking-[-0.03em]">{product.title}</h3>
        <div className="mt-auto flex items-baseline gap-2 pt-3">
          <span className="tabular-nums text-sm font-medium">{formatMoney(product.price)}</span>
          {product.compare_at_price && product.compare_at_price > product.price && (
            <span className="text-sm text-faint line-through tabular-nums">
              {formatMoney(product.compare_at_price)}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
