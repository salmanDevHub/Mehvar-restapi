import { cn } from "@/lib/utils";

export function MehvarMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-7", className)} aria-hidden="true">
      <rect width="32" height="32" rx="8" fill="currentColor" />
      <path
        d="M8 22.5V9.5h3.1l4.9 8.4 4.9-8.4H24v13h-2.7v-8.1l-4.2 7.1h-2.2l-4.2-7.1v8.1H8z"
        fill="#f3eee4"
      />
      <rect x="7" y="24.2" width="18" height="1.2" fill="#f3eee4" opacity="0.7" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-2.5 text-ink", className)}>
      <MehvarMark />
      <span className="font-display text-[1.35rem] leading-none tracking-[-0.04em]">MEHVAR</span>
    </span>
  );
}
