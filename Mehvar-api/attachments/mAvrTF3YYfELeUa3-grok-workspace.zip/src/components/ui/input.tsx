import { type InputHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn(
        "h-11 w-full rounded-md border border-border bg-surface px-3.5 text-sm text-ink placeholder:text-faint outline-none transition-colors focus:border-accent",
        className,
      )}
      {...props}
    />
  ),
);
Input.displayName = "Input";
