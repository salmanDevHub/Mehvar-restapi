import { Link } from "@tanstack/react-router";
import { Wordmark } from "@/components/brand/logo";

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border bg-bg-2">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <Wordmark />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
            MEHVAR is a modern marketplace API and storefront — noun-based resources, honest errors,
            idempotent orders, and responses that only send what you asked for.
          </p>
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-faint">Shop</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li>
              <Link to="/products" className="text-muted hover:text-ink">
                Catalog
              </Link>
            </li>
            <li>
              <Link to="/products" search={{ category: "electronics" }} className="text-muted hover:text-ink">
                Electronics
              </Link>
            </li>
            <li>
              <Link to="/products" search={{ category: "fashion" }} className="text-muted hover:text-ink">
                Fashion
              </Link>
            </li>
            <li>
              <Link to="/cart" className="text-muted hover:text-ink">
                Cart
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-faint">Platform</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li>
              <Link to="/docs" className="text-muted hover:text-ink">
                REST console
              </Link>
            </li>
            <li>
              <Link to="/orders" className="text-muted hover:text-ink">
                Orders
              </Link>
            </li>
            <li>
              <Link to="/login" className="text-muted hover:text-ink">
                Account
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <p className="mx-auto max-w-6xl px-4 py-4 text-xs text-faint sm:px-6">
          © {new Date().getFullYear()} MEHVAR. Built as an enterprise REST catalog — not a verb soup of /getProductsList.
        </p>
      </div>
    </footer>
  );
}
