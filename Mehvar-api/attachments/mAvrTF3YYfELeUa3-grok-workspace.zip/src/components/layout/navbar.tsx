import { Link, useNavigate } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag, X } from "lucide-react";
import { useState, type FormEvent } from "react";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { cartCount, useCart } from "@/lib/cart";
import { Wordmark } from "@/components/brand/logo";
import { useMe } from "@/hooks/use-me";

const NAV = [
  { to: "/products", label: "Catalog" },
  { to: "/docs", label: "API" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  const items = useCart((s) => s.items);
  const count = cartCount(items);
  const { isPending } = useCurrentUserState();
  const me = useMe();

  function onSearch(e: FormEvent) {
    e.preventDefault();
    const query = q.trim();
    setOpen(false);
    void navigate({ to: "/products", search: { search: query || undefined, page: 1 } });
  }

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-4 sm:h-[4.25rem] sm:px-6">
        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-full md:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>

        <Link to="/" className="shrink-0" onClick={() => setOpen(false)}>
          <Wordmark />
        </Link>

        <nav className="ml-4 hidden items-center gap-6 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="text-sm text-muted transition-colors hover:text-ink"
              activeProps={{ className: "text-ink" }}
            >
              {item.label}
            </Link>
          ))}
          {me.data?.role === "ADMIN" && (
            <Link to="/admin" className="text-sm text-muted transition-colors hover:text-ink">
              Studio
            </Link>
          )}
          <SignedIn>
            <Link to="/orders" className="text-sm text-muted transition-colors hover:text-ink">
              Orders
            </Link>
          </SignedIn>
        </nav>

        <form onSubmit={onSearch} className="ml-auto hidden min-w-0 flex-1 max-w-sm md:block">
          <label className="relative block">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search the catalog"
              className="h-10 w-full rounded-full border border-border bg-surface pl-10 pr-4 text-sm outline-none placeholder:text-faint focus:border-accent"
            />
          </label>
        </form>

        <div className="ml-auto flex items-center gap-1 md:ml-3">
          <Link
            to="/cart"
            className="relative inline-flex size-11 items-center justify-center rounded-full hover:bg-bg-2"
            aria-label="Cart"
          >
            <ShoppingBag className="size-5" />
            {count > 0 && (
              <span className="absolute right-1.5 top-1.5 min-w-4 rounded-full bg-accent px-1 text-center text-[10px] font-medium leading-4 text-accent-fg tabular-nums">
                {count}
              </span>
            )}
          </Link>

          {isPending ? (
            <div className="size-8 animate-pulse rounded-full bg-bg-2" />
          ) : (
            <>
              <SignedIn>
                <UserButton />
              </SignedIn>
              <SignedOut>
                <Link
                  to="/login"
                  className="hidden h-10 items-center rounded-full bg-ink px-4 text-sm font-medium text-bg sm:inline-flex"
                >
                  Sign in
                </Link>
              </SignedOut>
            </>
          )}
        </div>
      </div>

      {open && (
        <div className="border-t border-border bg-bg px-4 py-4 md:hidden">
          <form onSubmit={onSearch} className="mb-4">
            <label className="relative block">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search the catalog"
                className="h-11 w-full rounded-full border border-border bg-surface pl-10 pr-4 text-sm outline-none"
              />
            </label>
          </form>
          <div className="flex flex-col gap-1">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="rounded-md px-2 py-3 text-base"
              >
                {item.label}
              </Link>
            ))}
            {me.data?.role === "ADMIN" && (
              <Link to="/admin" onClick={() => setOpen(false)} className="rounded-md px-2 py-3 text-base">
                Studio
              </Link>
            )}
            <SignedIn>
              <Link to="/orders" onClick={() => setOpen(false)} className="rounded-md px-2 py-3 text-base">
                Orders
              </Link>
            </SignedIn>
            <SignedOut>
              <Link to="/login" onClick={() => setOpen(false)} className="rounded-md px-2 py-3 text-base">
                Sign in
              </Link>
            </SignedOut>
          </div>
        </div>
      )}
    </header>
  );
}
