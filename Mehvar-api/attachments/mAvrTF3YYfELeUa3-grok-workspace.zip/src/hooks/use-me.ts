import { useQuery } from "@tanstack/react-query";
import { getMe } from "@/lib/api";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export function useMe() {
  const { user, isPending } = useCurrentUserState();
  return useQuery({
    queryKey: ["me", user?.id ?? "anon"],
    queryFn: getMe,
    enabled: !isPending && Boolean(user),
    retry: false,
  });
}
