import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { getBearerToken } from "@/lib/auth/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/docs")({ component: DocsPage });

const EXAMPLES = [
  {
    name: "List products",
    method: "GET",
    path: "/api/v1/products?limit=5",
  },
  {
    name: "Filter + paginate",
    method: "GET",
    path: "/api/v1/products?category=electronics&page=1&limit=5",
  },
  {
    name: "Search",
    method: "GET",
    path: "/api/v1/products?search=headphones",
  },
  {
    name: "Field selection",
    method: "GET",
    path: "/api/v1/products/1?fields=title,price",
  },
  {
    name: "Invalid fields → 400",
    method: "GET",
    path: "/api/v1/products/1?fields=title,vendor_secrets",
  },
  {
    name: "Missing product → 404",
    method: "GET",
    path: "/api/v1/products/99999",
  },
  {
    name: "Current session",
    method: "GET",
    path: "/api/v1/auth/me",
  },
];

function DocsPage() {
  const [method, setMethod] = useState("GET");
  const [path, setPath] = useState("/api/v1/products/1?fields=title,price");
  const [body, setBody] = useState('{\n  "status": "paid"\n}');
  const [idem, setIdem] = useState("");
  const [result, setResult] = useState<string>("Send a request to see the live envelope.");
  const [status, setStatus] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);

  async function send() {
    setBusy(true);
    try {
      const headers: Record<string, string> = { Accept: "application/json" };
      const token = getBearerToken();
      if (token) headers.Authorization = `Bearer ${token}`;
      if (idem.trim()) headers["Idempotency-Key"] = idem.trim();
      const init: RequestInit = { method, headers, credentials: "include" };
      if (method !== "GET" && method !== "DELETE") {
        headers["Content-Type"] = "application/json";
        init.body = body;
      }
      const res = await fetch(path, init);
      setStatus(res.status);
      if (res.status === 204) {
        setResult("(no content)");
      } else {
        const json = await res.json().catch(() => null);
        setResult(JSON.stringify(json, null, 2));
      }
    } catch (err) {
      setStatus(null);
      setResult(err instanceof Error ? err.message : "Request failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6">
      <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Reference</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">REST console</h1>
      <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">
        MEHVAR exposes a versioned HTTP API at <code className="font-mono text-xs">/api/v1</code>. This
        console talks to the same handlers the storefront uses — no mocks.
      </p>

      <div className="mt-10 grid gap-4 md:grid-cols-2">
        <article className="rounded-xl bg-surface p-5 ring-1 ring-border">
          <h2 className="font-display text-2xl">Resources</h2>
          <ul className="mt-3 space-y-1 font-mono text-xs text-muted">
            <li>GET /api/v1/products</li>
            <li>GET /api/v1/products/{"{id}"}?fields=title,price</li>
            <li>POST /api/v1/products</li>
            <li>PUT /api/v1/products/{"{id}"}</li>
            <li>DELETE /api/v1/products/{"{id}"}</li>
            <li>GET|POST /api/v1/categories</li>
            <li>PUT|DELETE /api/v1/categories/{"{id}"}</li>
            <li>GET|POST /api/v1/orders · Idempotency-Key</li>
            <li>GET|PUT /api/v1/orders/{"{id}"}</li>
            <li>GET /api/v1/inventory</li>
            <li>GET /api/v1/auth/me</li>
          </ul>
        </article>
        <article className="rounded-xl bg-surface p-5 ring-1 ring-border">
          <h2 className="font-display text-2xl">Error envelope</h2>
          <pre className="mt-3 overflow-x-auto font-mono text-xs leading-relaxed text-muted">{`{
  "error_code": "PRODUCT_NOT_FOUND",
  "message": "Product with ID 123 was not found.",
  "timestamp": "2026-09-22T21:30:00Z",
  "path": "/api/v1/products/123"
}`}</pre>
        </article>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {EXAMPLES.map((ex) => (
          <button
            key={ex.name}
            type="button"
            onClick={() => {
              setMethod(ex.method);
              setPath(ex.path);
            }}
            className="rounded-full border border-border bg-surface px-3 py-1.5 text-xs hover:border-border-strong"
          >
            {ex.name}
          </button>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_1fr]">
        <div className="space-y-3">
          <div className="flex gap-2">
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              className="h-11 rounded-md border border-border bg-surface px-2 text-sm"
            >
              {["GET", "POST", "PUT", "DELETE"].map((m) => (
                <option key={m}>{m}</option>
              ))}
            </select>
            <Input value={path} onChange={(e) => setPath(e.target.value)} className="font-mono text-xs" />
          </div>
          {(method === "POST" || method === "PUT") && (
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={8}
              className="w-full rounded-md border border-border bg-surface p-3 font-mono text-xs outline-none focus:border-accent"
            />
          )}
          <Input
            value={idem}
            onChange={(e) => setIdem(e.target.value)}
            placeholder="Idempotency-Key (optional)"
            className="font-mono text-xs"
          />
          <Button onClick={() => void send()} disabled={busy}>
            {busy ? "Sending…" : "Send request"}
          </Button>
        </div>
        <div className="rounded-xl bg-ink p-4 text-bg">
          <p className="text-[11px] uppercase tracking-[0.16em] text-bg/60">
            {status == null ? "idle" : `HTTP ${status}`}
          </p>
          <pre className="mt-3 max-h-[420px] overflow-auto font-mono text-xs leading-relaxed text-bg/90">
            {result}
          </pre>
        </div>
      </div>
    </main>
  );
}
