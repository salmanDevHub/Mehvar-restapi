import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2 } from "lucide-react";
import { cartTotal, useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/utils";

export const Route = createFileRoute("/cart")({ component: CartPage });

function CartPage() {
  const items = useCart((s) => s.items);
  const setQty = useCart((s) => s.setQty);
  const remove = useCart((s) => s.remove);
  const total = cartTotal(items);

  return (
    <main className="mx-auto w-full max-w-5xl px-4 py-10 sm:px-6">
      <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Bag</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">Cart</h1>

      {items.length === 0 ? (
        <div className="mt-12 rounded-xl border border-dashed border-border-strong bg-surface px-6 py-16 text-center">
          <p className="font-display text-2xl">Your bag is empty</p>
          <p className="mt-2 text-sm text-muted">The floor is open. Start with featured pieces.</p>
          <Button asChild className="mt-6">
            <Link to="/products">Browse catalog</Link>
          </Button>
        </div>
      ) : (
        <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_280px]">
          <ul className="divide-y divide-border">
            {items.map((item) => (
              <li key={item.productId} className="flex gap-4 py-5">
                <img src={item.image} alt="" className="size-24 rounded-lg object-cover sm:size-28" />
                <div className="min-w-0 flex-1">
                  <Link
                    to="/products/$id"
                    params={{ id: String(item.productId) }}
                    className="font-display text-xl leading-tight"
                  >
                    {item.title}
                  </Link>
                  <p className="mt-1 text-sm tabular-nums text-muted">{formatMoney(item.price)}</p>
                  <div className="mt-3 flex items-center gap-2">
                    <div className="inline-flex h-9 items-center rounded-full border border-border">
                      <button
                        type="button"
                        className="inline-flex size-9 items-center justify-center"
                        onClick={() => setQty(item.productId, item.qty - 1)}
                      >
                        <Minus className="size-3.5" />
                      </button>
                      <span className="w-5 text-center text-sm tabular-nums">{item.qty}</span>
                      <button
                        type="button"
                        className="inline-flex size-9 items-center justify-center"
                        onClick={() => setQty(item.productId, item.qty + 1)}
                      >
                        <Plus className="size-3.5" />
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => remove(item.productId)}
                      className="inline-flex size-9 items-center justify-center rounded-full text-muted hover:text-danger"
                      aria-label="Remove"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>
                <p className="text-sm font-medium tabular-nums">{formatMoney(item.price * item.qty)}</p>
              </li>
            ))}
          </ul>
          <aside className="h-fit rounded-xl bg-surface p-5 ring-1 ring-border">
            <p className="text-sm text-muted">Subtotal</p>
            <p className="mt-1 font-display text-3xl tabular-nums">{formatMoney(total)}</p>
            <p className="mt-2 text-xs text-faint">Shipping is calculated at dispatch. Taxes included where required.</p>
            <Button asChild className="mt-5 w-full" size="lg">
              <Link to="/checkout">Checkout</Link>
            </Button>
          </aside>
        </div>
      )}
    </main>
  );
}
