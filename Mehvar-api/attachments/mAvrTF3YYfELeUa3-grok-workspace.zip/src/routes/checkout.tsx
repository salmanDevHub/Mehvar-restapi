import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useRef, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { createOrder, ApiClientError } from "@/lib/api";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { cartTotal, useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatMoney } from "@/lib/utils";

export const Route = createFileRoute("/checkout")({ component: CheckoutPage });

function CheckoutPage() {
  const { user, isPending } = useCurrentUserState();
  const items = useCart((s) => s.items);
  const clear = useCart((s) => s.clear);
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const keyRef = useRef(crypto.randomUUID());

  if (isPending) {
    return <main className="mx-auto max-w-xl px-4 py-20 text-sm text-muted">Checking your session…</main>;
  }
  if (!user) return <RedirectToSignIn />;

  if (items.length === 0) {
    return (
      <main className="mx-auto max-w-xl px-4 py-20 text-center">
        <p className="font-display text-3xl">Nothing to settle</p>
        <Button asChild className="mt-6">
          <Link to="/products">Return to catalog</Link>
        </Button>
      </main>
    );
  }

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const order = await createOrder(
        {
          shipping_name: String(form.get("shipping_name") ?? ""),
          shipping_address: String(form.get("shipping_address") ?? ""),
          shipping_city: String(form.get("shipping_city") ?? ""),
          shipping_phone: String(form.get("shipping_phone") ?? ""),
          notes: String(form.get("notes") ?? ""),
          items: items.map((item) => ({ product_id: item.productId, quantity: item.qty })),
        },
        keyRef.current,
      );
      clear();
      toast.success(`Order #${order.id} placed`);
      void navigate({ to: "/orders/$id", params: { id: String(order.id) } });
    } catch (err) {
      const message = err instanceof ApiClientError ? err.message : "Checkout failed.";
      toast.error(message);
      // Keep the same idempotency key so a retry cannot duplicate the order.
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto grid w-full max-w-5xl gap-10 px-4 py-10 sm:px-6 lg:grid-cols-[1fr_300px]">
      <div>
        <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Checkout</p>
        <h1 className="mt-2 font-display text-4xl">Dispatch details</h1>
        <p className="mt-3 max-w-lg text-sm text-muted">
          This form posts to <code className="font-mono text-xs">POST /api/v1/orders</code> with a stable{" "}
          <code className="font-mono text-xs">Idempotency-Key</code>. Retrying the same submit will not create a second order.
        </p>
        <form onSubmit={onSubmit} className="mt-8 space-y-4">
          <Field label="Full name" name="shipping_name" required />
          <Field label="Street address" name="shipping_address" required />
          <Field label="City" name="shipping_city" required />
          <Field label="Phone" name="shipping_phone" required />
          <label className="block text-sm">
            <span className="mb-1.5 block text-muted">Notes</span>
            <textarea
              name="notes"
              rows={3}
              className="w-full rounded-md border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:border-accent"
            />
          </label>
          <Button type="submit" size="lg" disabled={busy}>
            {busy ? "Placing order…" : "Place order"}
          </Button>
        </form>
      </div>
      <aside className="h-fit rounded-xl bg-surface p-5 ring-1 ring-border">
        <p className="text-sm font-medium">Summary</p>
        <ul className="mt-4 space-y-3 text-sm">
          {items.map((item) => (
            <li key={item.productId} className="flex justify-between gap-3">
              <span className="text-muted">
                {item.title} × {item.qty}
              </span>
              <span className="tabular-nums">{formatMoney(item.price * item.qty)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex justify-between border-t border-border pt-4">
          <span>Total</span>
          <span className="font-medium tabular-nums">{formatMoney(cartTotal(items))}</span>
        </div>
      </aside>
    </main>
  );
}

function Field({ label, name, required }: { label: string; name: string; required?: boolean }) {
  return (
    <label className="block text-sm">
      <span className="mb-1.5 block text-muted">{label}</span>
      <Input name={name} required={required} />
    </label>
  );
}
