import { createFileRoute, Link } from "@tanstack/react-router";
import type { ComponentProps } from "react";
import { useQuery } from "@tanstack/react-query";
import { listCategories, listProducts } from "@/lib/api";
import { ProductGrid, ProductGridSkeleton } from "@/components/product/product-grid";
import type { Product } from "@/lib/types";

type Search = {
  category?: string;
  search?: string;
  page?: number;
};

export const Route = createFileRoute("/products")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    category: typeof s.category === "string" ? s.category : undefined,
    search: typeof s.search === "string" ? s.search : undefined,
    page: typeof s.page === "number" ? s.page : s.page ? Number(s.page) || 1 : 1,
  }),
  component: ProductsPage,
});

function ProductsPage() {
  const search = Route.useSearch();
  const page = search.page ?? 1;
  const cats = useQuery({ queryKey: ["categories"], queryFn: listCategories });
  const catalog = useQuery({
    queryKey: ["products", search.category, search.search, page],
    queryFn: () =>
      listProducts({
        category: search.category,
        search: search.search,
        page,
        limit: 9,
      }),
  });

  const totalPages = catalog.data?.meta.total_pages ?? 0;

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6">
      <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Catalog</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">The floor</h1>
      <p className="mt-3 max-w-xl text-sm text-muted">
        Filter by department, search by title, and page through a paginated REST collection —{" "}
        <code className="font-mono text-xs">GET /api/v1/products</code>.
      </p>

      <div className="mt-8 flex flex-wrap gap-2">
        <FilterChip to="/products" search={{ search: search.search, page: 1 }} active={!search.category}>
          All
        </FilterChip>
        {(cats.data ?? []).map((cat) => (
          <FilterChip
            key={cat.id}
            to="/products"
            search={{ category: cat.slug, search: search.search, page: 1 }}
            active={search.category === cat.slug}
          >
            {cat.name}
          </FilterChip>
        ))}
      </div>

      {search.search && (
        <p className="mt-5 text-sm text-muted">
          Results for <span className="text-ink">“{search.search}”</span>
        </p>
      )}

      <div className="mt-8">
        {catalog.isLoading ? (
          <ProductGridSkeleton />
        ) : catalog.isError ? (
          <p className="rounded-xl border border-danger/30 bg-surface px-4 py-8 text-sm text-danger">
            The catalog could not be loaded. Try again in a moment.
          </p>
        ) : (
          <ProductGrid products={(catalog.data?.data ?? []) as Product[]} />
        )}
      </div>

      {totalPages > 1 && (
        <div className="mt-10 flex items-center justify-center gap-2">
          {Array.from({ length: totalPages }).map((_, i) => {
            const n = i + 1;
            return (
              <Link
                key={n}
                to="/products"
                search={{ ...search, page: n }}
                className={`inline-flex size-10 items-center justify-center rounded-full text-sm tabular-nums ${
                  n === page ? "bg-ink text-bg" : "border border-border hover:bg-bg-2"
                }`}
              >
                {n}
              </Link>
            );
          })}
        </div>
      )}
    </main>
  );
}

function FilterChip({
  children,
  active,
  ...props
}: ComponentProps<typeof Link> & { active: boolean }) {
  return (
    <Link
      {...props}
      className={`rounded-full px-3.5 py-2 text-sm ${
        active ? "bg-ink text-bg" : "border border-border bg-surface text-muted hover:text-ink"
      }`}
    >
      {children}
    </Link>
  );
}
