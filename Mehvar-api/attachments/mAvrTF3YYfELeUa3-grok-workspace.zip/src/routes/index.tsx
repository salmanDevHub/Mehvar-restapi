import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, KeyRound, Layers3, ShieldCheck, SlidersHorizontal } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { listCategories, listProducts } from "@/lib/api";
import { ProductGrid, ProductGridSkeleton } from "@/components/product/product-grid";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const featured = useQuery({
    queryKey: ["products", "featured"],
    queryFn: () => listProducts({ featured: true, limit: 6 }),
  });
  const categories = useQuery({
    queryKey: ["categories"],
    queryFn: listCategories,
  });

  return (
    <main>
      <section className="relative overflow-hidden border-b border-border">
        <div className="mx-auto grid max-w-6xl items-end gap-10 px-4 py-14 sm:px-6 lg:grid-cols-12 lg:py-20">
          <div className="lg:col-span-7">
            <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Marketplace, recalibrated</p>
            <h1 className="mt-4 font-display text-[2.7rem] leading-[0.95] tracking-[-0.04em] sm:text-6xl lg:text-[4.4rem]">
              Commerce on its true axis.
            </h1>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
              MEHVAR is a full-stack storefront and enterprise REST catalog. Noun-based URIs, honest
              HTTP status codes, idempotent checkout, and field selection so mobile clients never
              download a 50-field product they did not ask for.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/products">
                  Shop the catalog <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/docs">Open the API console</Link>
              </Button>
            </div>
          </div>
          <div className="lg:col-span-5">
            <div className="grid grid-cols-2 gap-3">
              <img
                src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80"
                alt="Aurora headphones"
                className="h-52 w-full rounded-xl object-cover sm:h-64"
              />
              <img
                src="https://images.unsplash.com/photo-1539533018447-63fcce2678e3?auto=format&fit=crop&w=900&q=80"
                alt="Midnight overcoat"
                className="mt-8 h-52 w-full rounded-xl object-cover sm:h-64"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Departments</p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">Shop by aisle</h2>
          </div>
          <Link to="/products" className="hidden text-sm text-muted hover:text-ink sm:inline">
            View all
          </Link>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {(categories.data ?? []).map((cat) => (
            <Link
              key={cat.id}
              to="/products"
              search={{ category: cat.slug }}
              className="group relative overflow-hidden rounded-xl bg-bg-2 ring-1 ring-border"
            >
              <img src={cat.image_url} alt="" className="h-40 w-full object-cover opacity-90 transition-transform duration-500 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent" />
              <p className="absolute bottom-3 left-3 font-display text-lg text-bg">{cat.name}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-muted">This week</p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">Featured pieces</h2>
          </div>
        </div>
        <div className="mt-8">
          {featured.isLoading ? (
            <ProductGridSkeleton />
          ) : (
            <ProductGrid products={(featured.data?.data ?? []) as import("@/lib/types").Product[]} />
          )}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Architecture</p>
        <h2 className="mt-2 max-w-2xl font-display text-3xl sm:text-4xl">
          Four promises the old backend never kept.
        </h2>
        <div className="mt-10 grid gap-4 md:grid-cols-2">
          {[
            {
              icon: Layers3,
              title: "Noun-based REST",
              body: "/api/v1/products, not /getProductsList. GET, POST, PUT, DELETE mean what they always should have.",
            },
            {
              icon: ShieldCheck,
              title: "Honest errors",
              body: "400 for bad input, 404 for missing resources, 201 for creation. One JSON envelope: error_code, message, timestamp, path.",
            },
            {
              icon: KeyRound,
              title: "Idempotent checkout",
              body: "Send Idempotency-Key on POST /orders. Network retries never double-charge a cart or duplicate a deduction.",
            },
            {
              icon: SlidersHorizontal,
              title: "Field selection",
              body: "?fields=title,price returns only those keys. Invalid fields are rejected with a clean 400 — never a 500.",
            },
          ].map((item) => (
            <article key={item.title} className="rounded-xl bg-surface p-6 ring-1 ring-border">
              <item.icon className="size-5 text-accent" />
              <h3 className="mt-4 font-display text-2xl">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{item.body}</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
