import { createFileRoute } from "@tanstack/react-router";
import { requireAdmin } from "@/server/authz.server";
import { created, readJson, wrap } from "@/server/http";
import { createCategory, listCategories } from "@/server/categories.server";

export const Route = createFileRoute("/api/v1/categories")({
  server: {
    handlers: {
      GET: wrap(async () => Response.json(await listCategories())),
      POST: wrap(async ({ request }) => {
        await requireAdmin(request);
        const category = await createCategory(await readJson(request));
        return created(category, `/api/v1/categories/${category.id}`);
      }),
    },
  },
});
