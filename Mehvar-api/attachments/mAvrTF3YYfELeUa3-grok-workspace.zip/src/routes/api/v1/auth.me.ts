import { createFileRoute } from "@tanstack/react-router";
import { mePayload } from "@/server/authz.server";
import { wrap } from "@/server/http";

export const Route = createFileRoute("/api/v1/auth/me")({
  server: {
    handlers: {
      GET: wrap(async ({ request }) => Response.json(await mePayload(request))),
    },
  },
});
