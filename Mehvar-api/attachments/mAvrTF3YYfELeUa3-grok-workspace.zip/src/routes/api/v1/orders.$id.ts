import { createFileRoute } from "@tanstack/react-router";
import { ensureProfile, requireAdmin, requireUser } from "@/server/authz.server";
import { parseId, readJson, wrap } from "@/server/http";
import { getOrderForUser, updateOrderStatus } from "@/server/orders.server";

export const Route = createFileRoute("/api/v1/orders/$id")({
  server: {
    handlers: {
      GET: wrap(async ({ request, params }) => {
        const user = await requireUser(request);
        const profile = await ensureProfile(user.id, user.email);
        const order = await getOrderForUser(parseId(params.id, "Order ID"), user.id, profile.role === "ADMIN");
        return Response.json(order);
      }),
      PUT: wrap(async ({ request, params }) => {
        await requireAdmin(request);
        const order = await updateOrderStatus(parseId(params.id, "Order ID"), await readJson(request));
        return Response.json(order);
      }),
    },
  },
});
