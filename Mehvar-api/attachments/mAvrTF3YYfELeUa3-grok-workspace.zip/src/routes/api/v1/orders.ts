import { createFileRoute } from "@tanstack/react-router";
import { ensureProfile, requireUser } from "@/server/authz.server";
import { created, readJson, wrap } from "@/server/http";
import { createOrder, listOrdersForUser } from "@/server/orders.server";

export const Route = createFileRoute("/api/v1/orders")({
  server: {
    handlers: {
      GET: wrap(async ({ request }) => {
        const user = await requireUser(request);
        const profile = await ensureProfile(user.id, user.email);
        const result = await listOrdersForUser(user.id, new URL(request.url), profile.role === "ADMIN");
        return Response.json(result);
      }),
      POST: wrap(async ({ request }) => {
        const user = await requireUser(request);
        await ensureProfile(user.id, user.email);
        const key = request.headers.get("Idempotency-Key") ?? request.headers.get("idempotency-key");
        const result = await createOrder(user.id, await readJson(request), key);
        if (result.replayed) {
          return Response.json(result.body, {
            status: result.status || 200,
            headers: { "Idempotency-Replayed": "true" },
          });
        }
        const order = result.body as { id: number };
        return created(result.body, `/api/v1/orders/${order.id}`);
      }),
    },
  },
});
