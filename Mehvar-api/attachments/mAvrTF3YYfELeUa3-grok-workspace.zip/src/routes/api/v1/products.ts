import { createFileRoute } from "@tanstack/react-router";
import { requireAdmin } from "@/server/authz.server";
import { created, readJson, wrap } from "@/server/http";
import { createProduct, listProducts } from "@/server/products.server";

export const Route = createFileRoute("/api/v1/products")({
  server: {
    handlers: {
      GET: wrap(async ({ request }) => {
        const url = new URL(request.url);
        const result = await listProducts(url);
        return Response.json(result);
      }),
      POST: wrap(async ({ request }) => {
        await requireAdmin(request);
        const body = await readJson(request);
        const product = await createProduct(body);
        return created(product, `/api/v1/products/${product.id}`);
      }),
    },
  },
});
