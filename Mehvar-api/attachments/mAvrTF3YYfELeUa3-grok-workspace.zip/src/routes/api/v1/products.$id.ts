import { createFileRoute } from "@tanstack/react-router";
import { requireAdmin } from "@/server/authz.server";
import { parseId, readJson, wrap } from "@/server/http";
import { deleteProduct, getProduct, updateProduct } from "@/server/products.server";

export const Route = createFileRoute("/api/v1/products/$id")({
  server: {
    handlers: {
      GET: wrap(async ({ request, params }) => {
        const url = new URL(request.url);
        const product = await getProduct(parseId(params.id, "Product ID"), url.searchParams.get("fields"));
        return Response.json(product);
      }),
      PUT: wrap(async ({ request, params }) => {
        await requireAdmin(request);
        const body = await readJson(request);
        const product = await updateProduct(parseId(params.id, "Product ID"), body);
        return Response.json(product);
      }),
      DELETE: wrap(async ({ request, params }) => {
        await requireAdmin(request);
        await deleteProduct(parseId(params.id, "Product ID"));
        return new Response(null, { status: 204 });
      }),
    },
  },
});
