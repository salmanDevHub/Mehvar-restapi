import { createFileRoute } from "@tanstack/react-router";
import { requireAdmin } from "@/server/authz.server";
import { wrap } from "@/server/http";
import { listInventory } from "@/server/products.server";

export const Route = createFileRoute("/api/v1/inventory")({
  server: {
    handlers: {
      GET: wrap(async ({ request }) => {
        await requireAdmin(request);
        return Response.json(await listInventory());
      }),
    },
  },
});
