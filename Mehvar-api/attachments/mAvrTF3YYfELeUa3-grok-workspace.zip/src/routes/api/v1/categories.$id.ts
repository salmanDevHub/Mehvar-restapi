import { createFileRoute } from "@tanstack/react-router";
import { requireAdmin } from "@/server/authz.server";
import { parseId, readJson, wrap } from "@/server/http";
import { deleteCategory, getCategory, updateCategory } from "@/server/categories.server";

export const Route = createFileRoute("/api/v1/categories/$id")({
  server: {
    handlers: {
      GET: wrap(async ({ params }) => Response.json(await getCategory(parseId(params.id, "Category ID")))),
      PUT: wrap(async ({ request, params }) => {
        await requireAdmin(request);
        const category = await updateCategory(parseId(params.id, "Category ID"), await readJson(request));
        return Response.json(category);
      }),
      DELETE: wrap(async ({ request, params }) => {
        await requireAdmin(request);
        await deleteCategory(parseId(params.id, "Category ID"));
        return new Response(null, { status: 204 });
      }),
    },
  },
});
