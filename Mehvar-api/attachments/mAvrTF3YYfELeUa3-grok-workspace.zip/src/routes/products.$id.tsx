import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Minus, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { getProduct } from "@/lib/api";
import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/utils";
import type { Product } from "@/lib/types";

export const Route = createFileRoute("/products/$id")({
  component: ProductPage,
});

function ProductPage() {
  const { id } = Route.useParams();
  const productId = Number(id);
  const [lean, setLean] = useState(false);
  const [qty, setQty] = useState(1);
  const add = useCart((s) => s.add);

  const query = useQuery({
    queryKey: ["product", productId, lean],
    queryFn: () => getProduct(productId, lean ? "title,price" : undefined),
    enabled: Number.isInteger(productId),
  });

  if (!Number.isInteger(productId)) {
    return <main className="mx-auto max-w-3xl px-4 py-16">Invalid product.</main>;
  }

  if (query.isLoading) {
    return (
      <main className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-2">
        <div className="aspect-[4/5] animate-pulse rounded-xl bg-bg-2" />
        <div className="space-y-4">
          <div className="h-8 w-2/3 animate-pulse rounded bg-bg-2" />
          <div className="h-4 w-1/3 animate-pulse rounded bg-bg-2" />
          <div className="h-24 w-full animate-pulse rounded bg-bg-2" />
        </div>
      </main>
    );
  }

  if (query.isError || !query.data) {
    return (
      <main className="mx-auto max-w-xl px-4 py-20 text-center">
        <p className="font-display text-3xl">This piece is not on the floor</p>
        <p className="mt-2 text-sm text-muted">The API returned 404 with a structured error envelope.</p>
        <Button asChild className="mt-6">
          <Link to="/products">Back to catalog</Link>
        </Button>
      </main>
    );
  }

  const product = query.data as Partial<Product>;
  const full = !lean && Boolean(product.description);

  function addToCart() {
    if (!product.id || product.price == null || !product.title || !product.image_url) return;
    add(
      {
        productId: product.id,
        title: product.title,
        price: product.price,
        image: product.image_url,
        stock: product.stock ?? 1,
      },
      qty,
    );
    toast.success("Added to cart");
  }

  return (
    <main className="mx-auto grid max-w-6xl gap-10 px-4 py-10 sm:px-6 lg:grid-cols-2 lg:py-14">
      <div>
        {product.image_url ? (
          <img
            src={product.image_url}
            alt={product.title ?? "Product"}
            className="aspect-[4/5] w-full rounded-xl object-cover"
          />
        ) : (
          <div className="flex aspect-[4/5] items-center justify-center rounded-xl bg-bg-2 text-sm text-muted">
            Image omitted by field selection
          </div>
        )}
        {full && product.gallery && product.gallery.length > 0 && (
          <div className="mt-3 grid grid-cols-3 gap-3">
            {product.gallery.map((src) => (
              <img key={src} src={src} alt="" className="aspect-square rounded-lg object-cover" />
            ))}
          </div>
        )}
      </div>

      <div>
        <p className="text-[11px] uppercase tracking-[0.22em] text-muted">
          {product.brand || product.category || "MEHVAR"}
        </p>
        <h1 className="mt-2 font-display text-4xl sm:text-5xl">{product.title ?? "Untitled"}</h1>
        {product.price != null && (
          <p className="mt-4 text-xl tabular-nums">
            {formatMoney(product.price)}
            {product.compare_at_price && product.compare_at_price > product.price && (
              <span className="ml-3 text-base text-faint line-through">{formatMoney(product.compare_at_price)}</span>
            )}
          </p>
        )}

        {full && product.description && (
          <p className="mt-6 text-[15px] leading-relaxed text-muted">{product.description}</p>
        )}

        {full && (
          <dl className="mt-8 grid grid-cols-2 gap-4 text-sm">
            <div>
              <dt className="text-faint">SKU</dt>
              <dd className="mt-1 font-mono text-xs">{product.sku}</dd>
            </div>
            <div>
              <dt className="text-faint">Stock</dt>
              <dd className="mt-1 tabular-nums">{product.stock} in warehouse</dd>
            </div>
            <div>
              <dt className="text-faint">Rating</dt>
              <dd className="mt-1 tabular-nums">
                {product.rating} · {product.review_count} reviews
              </dd>
            </div>
            <div>
              <dt className="text-faint">Department</dt>
              <dd className="mt-1">{product.category}</dd>
            </div>
          </dl>
        )}

        <div className="mt-8 flex items-center gap-3">
          <div className="inline-flex h-11 items-center rounded-full border border-border">
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center"
              onClick={() => setQty((q) => Math.max(1, q - 1))}
              aria-label="Decrease quantity"
            >
              <Minus className="size-4" />
            </button>
            <span className="w-6 text-center tabular-nums text-sm">{qty}</span>
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center"
              onClick={() => setQty((q) => q + 1)}
              aria-label="Increase quantity"
            >
              <Plus className="size-4" />
            </button>
          </div>
          <Button size="lg" onClick={addToCart} disabled={!product.stock}>
            {product.stock === 0 ? "Sold out" : "Add to cart"}
          </Button>
        </div>

        <div className="mt-10 rounded-xl bg-bg-2 p-4 ring-1 ring-border">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-sm font-medium">Bandwidth mode</p>
              <p className="mt-1 text-xs leading-relaxed text-muted">
                When on, this page calls{" "}
                <code className="font-mono">GET /api/v1/products/{id}?fields=title,price</code> and
                renders only those keys — the over-fetching fix.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setLean((v) => !v)}
              className={`relative h-7 w-12 rounded-full transition-colors ${lean ? "bg-accent" : "bg-border-strong"}`}
              aria-pressed={lean}
            >
              <span
                className={`absolute top-0.5 size-6 rounded-full bg-surface transition-transform ${
                  lean ? "translate-x-5" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}
