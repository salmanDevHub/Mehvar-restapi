import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { getInventory, listOrders, listProducts } from "@/lib/api";
import { formatMoney } from "@/lib/utils";

export const Route = createFileRoute("/admin/")({ component: AdminHome });

function AdminHome() {
  const products = useQuery({ queryKey: ["admin", "products"], queryFn: () => listProducts({ limit: 50 }) });
  const orders = useQuery({ queryKey: ["admin", "orders"], queryFn: () => listOrders({ limit: 50 }) });
  const inventory = useQuery({ queryKey: ["admin", "inventory"], queryFn: getInventory });

  const low = (inventory.data ?? []).filter((row) => row.stock <= 15);
  const revenue = (orders.data?.data ?? []).reduce((sum, o) => sum + o.total, 0);

  return (
    <div className="space-y-8">
      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="SKUs on floor" value={String(products.data?.meta.total ?? "—")} />
        <Stat label="Orders" value={String(orders.data?.meta.total ?? "—")} />
        <Stat label="Recorded volume" value={formatMoney(revenue)} />
      </div>
      <section>
        <h2 className="font-display text-2xl">Inventory watch</h2>
        <p className="mt-1 text-sm text-muted">Units at or below 15. Pulled from GET /api/v1/inventory.</p>
        <div className="mt-4 overflow-x-auto rounded-xl bg-surface ring-1 ring-border">
          <table className="w-full min-w-[520px] text-left text-sm">
            <thead className="border-b border-border text-xs uppercase tracking-[0.12em] text-faint">
              <tr>
                <th className="px-4 py-3 font-medium">Product</th>
                <th className="px-4 py-3 font-medium">SKU</th>
                <th className="px-4 py-3 font-medium">Dept</th>
                <th className="px-4 py-3 font-medium">Stock</th>
              </tr>
            </thead>
            <tbody>
              {low.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-muted">
                    All watched SKUs are healthy.
                  </td>
                </tr>
              )}
              {low.map((row) => (
                <tr key={row.id} className="border-t border-border">
                  <td className="px-4 py-3">{row.title}</td>
                  <td className="px-4 py-3 font-mono text-xs">{row.sku}</td>
                  <td className="px-4 py-3 text-muted">{row.category}</td>
                  <td className="px-4 py-3 tabular-nums">{row.stock}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface p-5 ring-1 ring-border">
      <p className="text-xs uppercase tracking-[0.14em] text-faint">{label}</p>
      <p className="mt-2 font-display text-3xl tabular-nums">{value}</p>
    </div>
  );
}
