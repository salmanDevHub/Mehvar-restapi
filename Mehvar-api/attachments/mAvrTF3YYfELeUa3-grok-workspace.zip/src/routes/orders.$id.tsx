import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { getOrder } from "@/lib/api";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { formatDate, formatMoney } from "@/lib/utils";

export const Route = createFileRoute("/orders/$id")({ component: OrderDetailPage });

function OrderDetailPage() {
  const { id } = Route.useParams();
  const { user, isPending } = useCurrentUserState();
  const query = useQuery({
    queryKey: ["order", id],
    queryFn: () => getOrder(Number(id)),
    enabled: !isPending && Boolean(user),
  });

  if (isPending) return <main className="px-4 py-16 text-sm text-muted">Loading…</main>;
  if (!user) return <RedirectToSignIn />;

  if (query.isLoading) {
    return <main className="mx-auto max-w-2xl px-4 py-16"><div className="h-64 animate-pulse rounded-xl bg-bg-2" /></main>;
  }
  if (query.isError || !query.data) {
    return (
      <main className="mx-auto max-w-xl px-4 py-20 text-center">
        <p className="font-display text-3xl">Order not found</p>
        <Link to="/orders" className="mt-4 inline-block text-sm text-muted hover:text-ink">
          Back to orders
        </Link>
      </main>
    );
  }

  const order = query.data;

  return (
    <main className="mx-auto w-full max-w-2xl px-4 py-10 sm:px-6">
      <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Order #{order.id}</p>
      <h1 className="mt-2 font-display text-4xl">{formatMoney(order.total)}</h1>
      <p className="mt-2 text-sm text-muted">
        {formatDate(order.created_at)} · <span className="uppercase tracking-[0.12em]">{order.status}</span>
      </p>
      <ul className="mt-8 divide-y divide-border rounded-xl bg-surface ring-1 ring-border">
        {order.items.map((item) => (
          <li key={item.id} className="flex justify-between gap-4 px-5 py-4 text-sm">
            <span>
              {item.title} × {item.quantity}
            </span>
            <span className="tabular-nums">{formatMoney(item.line_total)}</span>
          </li>
        ))}
      </ul>
      <div className="mt-6 text-sm text-muted">
        <p className="font-medium text-ink">Ship to</p>
        <p className="mt-1">
          {order.shipping_name}
          <br />
          {order.shipping_address}
          <br />
          {order.shipping_city}
        </p>
      </div>
    </main>
  );
}
