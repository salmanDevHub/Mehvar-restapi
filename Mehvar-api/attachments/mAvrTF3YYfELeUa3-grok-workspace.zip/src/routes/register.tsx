import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Wordmark } from "@/components/brand/logo";

export const Route = createFileRoute("/register")({ component: Register });

function Register() {
  const { user, isPending } = useCurrentUserState();
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!isPending && user) return <Navigate to="/" />;

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    const form = new FormData(e.currentTarget);
    const name = String(form.get("name") ?? "");
    const email = String(form.get("email") ?? "");
    const password = String(form.get("password") ?? "");
    const { error: err } = await authClient.signUp.email({ name, email, password });
    setBusy(false);
    if (err) {
      setError(err.message ?? "Could not create that account.");
      return;
    }
    window.location.href = "/";
  }

  return (
    <main className="mx-auto flex w-full max-w-md flex-col px-4 py-14 sm:px-6">
      <Wordmark />
      <h1 className="mt-8 font-display text-4xl">Open an account</h1>
      <p className="mt-2 text-sm text-muted">
        The first registered member becomes Studio admin so the floor can be merchandised.
      </p>

      {authEnabled ? (
        <>
          <form onSubmit={onSubmit} className="mt-8 space-y-3">
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">Name</span>
              <Input name="name" autoComplete="name" required />
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">Email</span>
              <Input name="email" type="email" autoComplete="email" required />
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">Password</span>
              <Input name="password" type="password" autoComplete="new-password" required minLength={8} />
            </label>
            {error && <p className="text-sm text-danger">{error}</p>}
            <Button type="submit" className="w-full" size="lg" disabled={busy}>
              {busy ? "Creating…" : "Create account"}
            </Button>
          </form>
          <div className="my-6 flex items-center gap-3 text-xs uppercase tracking-[0.16em] text-faint">
            <span className="h-px flex-1 bg-border" />
            or
            <span className="h-px flex-1 bg-border" />
          </div>
          <div className="space-y-2">
            {GROK_PROVIDERS.map((p) => (
              <button
                key={p.providerId}
                type="button"
                onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                className="h-11 w-full rounded-full border border-border-strong text-sm hover:bg-bg-2"
              >
                Continue with {p.label}
              </button>
            ))}
          </div>
        </>
      ) : (
        <p className="mt-6 text-sm text-muted">Registration is disabled.</p>
      )}

      <p className="mt-8 text-sm text-muted">
        Already have an account?{" "}
        <Link to="/login" className="text-ink underline decoration-border-strong underline-offset-4">
          Sign in
        </Link>
      </p>
    </main>
  );
}
