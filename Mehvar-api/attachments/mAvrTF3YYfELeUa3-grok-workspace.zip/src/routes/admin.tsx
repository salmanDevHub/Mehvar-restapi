import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useMe } from "@/hooks/use-me";

export const Route = createFileRoute("/admin")({ component: AdminLayout });

function AdminLayout() {
  const { user, isPending } = useCurrentUserState();
  const me = useMe();

  if (isPending || me.isLoading) {
    return <main className="px-4 py-16 text-sm text-muted">Opening Studio…</main>;
  }
  if (!user) return <RedirectToSignIn />;
  if (me.data?.role !== "ADMIN") {
    return (
      <main className="mx-auto max-w-lg px-4 py-20 text-center">
        <p className="font-display text-3xl">Studio is locked</p>
        <p className="mt-2 text-sm text-muted">
          This account is a customer. The first member to register on a fresh MEHVAR floor becomes admin.
        </p>
      </main>
    );
  }

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Operations</p>
          <h1 className="mt-1 font-display text-4xl">Studio</h1>
        </div>
        <nav className="flex flex-wrap gap-2">
          <AdminLink to="/admin">Overview</AdminLink>
          <AdminLink to="/admin/products">Products</AdminLink>
          <AdminLink to="/admin/orders">Orders</AdminLink>
        </nav>
      </div>
      <div className="mt-8">
        <Outlet />
      </div>
    </main>
  );
}

function AdminLink({ to, children }: { to: "/admin" | "/admin/products" | "/admin/orders"; children: string }) {
  return (
    <Link
      to={to}
      className="rounded-full border border-border px-3.5 py-2 text-sm text-muted hover:text-ink"
      activeProps={{ className: "rounded-full bg-ink px-3.5 py-2 text-sm text-bg" }}
      activeOptions={{ exact: to === "/admin" }}
    >
      {children}
    </Link>
  );
}
