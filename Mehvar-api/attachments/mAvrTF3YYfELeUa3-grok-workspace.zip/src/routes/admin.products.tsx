import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type ComponentProps, type FormEvent } from "react";
import { toast } from "sonner";
import {
  ApiClientError,
  createProduct,
  deleteProduct,
  listCategories,
  listProducts,
  updateProduct,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatMoney } from "@/lib/utils";
import type { Product } from "@/lib/types";

export const Route = createFileRoute("/admin/products")({ component: AdminProducts });

function AdminProducts() {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<Product | null>(null);
  const [creating, setCreating] = useState(false);
  const products = useQuery({ queryKey: ["admin", "products-all"], queryFn: () => listProducts({ limit: 50 }) });
  const categories = useQuery({ queryKey: ["categories"], queryFn: listCategories });

  const remove = useMutation({
    mutationFn: (id: number) => deleteProduct(id),
    onSuccess: () => {
      toast.success("Product removed");
      void qc.invalidateQueries({ queryKey: ["admin"] });
      void qc.invalidateQueries({ queryKey: ["products"] });
    },
    onError: (err) => toast.error(err instanceof ApiClientError ? err.message : "Could not delete"),
  });

  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-2xl">Merchandise</h2>
        <Button size="sm" onClick={() => { setCreating(true); setEditing(null); }}>
          New product
        </Button>
      </div>
      {(creating || editing) && (
        <ProductForm
          key={editing?.id ?? "new"}
          initial={editing}
          categories={categories.data ?? []}
          onCancel={() => {
            setCreating(false);
            setEditing(null);
          }}
          onSaved={() => {
            setCreating(false);
            setEditing(null);
            void qc.invalidateQueries({ queryKey: ["admin"] });
            void qc.invalidateQueries({ queryKey: ["products"] });
          }}
        />
      )}
      <div className="mt-6 overflow-x-auto rounded-xl bg-surface ring-1 ring-border">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="border-b border-border text-xs uppercase tracking-[0.12em] text-faint">
            <tr>
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="px-4 py-3 font-medium">Price</th>
              <th className="px-4 py-3 font-medium">Stock</th>
              <th className="px-4 py-3 font-medium">Dept</th>
              <th className="px-4 py-3 font-medium" />
            </tr>
          </thead>
          <tbody>
            {(products.data?.data ?? []).map((row) => {
              const p = row as Product;
              return (
                <tr key={p.id} className="border-t border-border">
                  <td className="px-4 py-3">{p.title}</td>
                  <td className="px-4 py-3 tabular-nums">{formatMoney(p.price)}</td>
                  <td className="px-4 py-3 tabular-nums">{p.stock}</td>
                  <td className="px-4 py-3 text-muted">{p.category}</td>
                  <td className="px-4 py-3 text-right">
                    <button
                      type="button"
                      className="mr-3 text-xs uppercase tracking-[0.12em] text-muted hover:text-ink"
                      onClick={() => {
                        setEditing(p);
                        setCreating(false);
                      }}
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      className="text-xs uppercase tracking-[0.12em] text-danger"
                      onClick={() => remove.mutate(p.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ProductForm({
  initial,
  categories,
  onCancel,
  onSaved,
}: {
  initial: Product | null;
  categories: { id: number; name: string }[];
  onCancel: () => void;
  onSaved: () => void;
}) {
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const body = {
      title: String(form.get("title") ?? ""),
      description: String(form.get("description") ?? ""),
      price: Number(form.get("price")),
      compare_at_price: form.get("compare_at_price") ? Number(form.get("compare_at_price")) : null,
      stock: Number(form.get("stock")),
      category_id: Number(form.get("category_id")),
      image_url: String(form.get("image_url") ?? ""),
      brand: String(form.get("brand") ?? ""),
      sku: String(form.get("sku") ?? "") || undefined,
      featured: form.get("featured") === "on",
    };
    setBusy(true);
    try {
      if (initial) await updateProduct(initial.id, body);
      else await createProduct(body);
      toast.success(initial ? "Product updated" : "Product created");
      onSaved();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="mt-6 grid gap-3 rounded-xl bg-surface p-5 ring-1 ring-border sm:grid-cols-2">
      <Field label="Title" name="title" defaultValue={initial?.title} required />
      <Field label="Brand" name="brand" defaultValue={initial?.brand} />
      <label className="sm:col-span-2 text-sm">
        <span className="mb-1.5 block text-muted">Description</span>
        <textarea
          name="description"
          required
          minLength={12}
          defaultValue={initial?.description}
          rows={3}
          className="w-full rounded-md border border-border bg-bg px-3.5 py-2.5 text-sm outline-none focus:border-accent"
        />
      </label>
      <Field label="Price" name="price" type="number" step="0.01" defaultValue={initial?.price} required />
      <Field
        label="Compare-at price"
        name="compare_at_price"
        type="number"
        step="0.01"
        defaultValue={initial?.compare_at_price ?? ""}
      />
      <Field label="Stock" name="stock" type="number" defaultValue={initial?.stock ?? 0} required />
      <label className="text-sm">
        <span className="mb-1.5 block text-muted">Category</span>
        <select
          name="category_id"
          defaultValue={initial?.category_id}
          className="h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
          required
        >
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </label>
      <Field label="Image URL" name="image_url" defaultValue={initial?.image_url} required className="sm:col-span-2" />
      <Field label="SKU (optional)" name="sku" defaultValue={initial?.sku} />
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="featured" defaultChecked={initial?.featured} />
        Featured
      </label>
      <div className="flex gap-2 sm:col-span-2">
        <Button type="submit" disabled={busy}>
          {busy ? "Saving…" : initial ? "Save (idempotent PUT)" : "Create"}
        </Button>
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}

function Field(props: ComponentProps<typeof Input> & { label: string }) {
  const { label, className, ...rest } = props;
  return (
    <label className={`text-sm ${className ?? ""}`}>
      <span className="mb-1.5 block text-muted">{label}</span>
      <Input {...rest} />
    </label>
  );
}
