import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { listOrders } from "@/lib/api";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { formatDate, formatMoney } from "@/lib/utils";

export const Route = createFileRoute("/orders")({ component: OrdersPage });

function OrdersPage() {
  const { user, isPending } = useCurrentUserState();
  const query = useQuery({
    queryKey: ["orders", user?.id],
    queryFn: () => listOrders({ limit: 20 }),
    enabled: !isPending && Boolean(user),
  });

  if (isPending) return <main className="px-4 py-16 text-sm text-muted">Loading…</main>;
  if (!user) return <RedirectToSignIn />;

  const orders = query.data?.data ?? [];

  return (
    <main className="mx-auto w-full max-w-4xl px-4 py-10 sm:px-6">
      <p className="text-[11px] uppercase tracking-[0.22em] text-muted">Account</p>
      <h1 className="mt-2 font-display text-4xl">Orders</h1>
      {query.isLoading ? (
        <div className="mt-8 space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-24 animate-pulse rounded-xl bg-bg-2" />
          ))}
        </div>
      ) : orders.length === 0 ? (
        <div className="mt-10 rounded-xl border border-dashed border-border-strong bg-surface px-6 py-16 text-center">
          <p className="font-display text-2xl">No orders yet</p>
          <p className="mt-2 text-sm text-muted">When you checkout, they will appear here — scoped to your account.</p>
        </div>
      ) : (
        <ul className="mt-8 divide-y divide-border overflow-hidden rounded-xl bg-surface ring-1 ring-border">
          {orders.map((order) => (
            <li key={order.id}>
              <Link
                to="/orders/$id"
                params={{ id: String(order.id) }}
                className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 hover:bg-bg-2"
              >
                <div>
                  <p className="font-medium">Order #{order.id}</p>
                  <p className="text-sm text-muted">
                    {formatDate(order.created_at)} · {order.items.length} item{order.items.length === 1 ? "" : "s"}
                  </p>
                </div>
                <div className="text-right">
                  <p className="tabular-nums">{formatMoney(order.total)}</p>
                  <p className="text-xs uppercase tracking-[0.14em] text-muted">{order.status}</p>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
