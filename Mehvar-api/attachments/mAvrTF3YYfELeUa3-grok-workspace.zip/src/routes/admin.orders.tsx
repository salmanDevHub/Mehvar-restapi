import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ApiClientError, listOrders, updateOrderStatus } from "@/lib/api";
import { formatDate, formatMoney } from "@/lib/utils";
import type { OrderStatus } from "@/lib/types";

const STATUSES: OrderStatus[] = ["pending", "paid", "packed", "shipped", "delivered", "cancelled"];

export const Route = createFileRoute("/admin/orders")({ component: AdminOrders });

function AdminOrders() {
  const qc = useQueryClient();
  const orders = useQuery({ queryKey: ["admin", "orders-all"], queryFn: () => listOrders({ limit: 50 }) });
  const mutate = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => updateOrderStatus(id, status),
    onSuccess: () => {
      toast.success("Order updated");
      void qc.invalidateQueries({ queryKey: ["admin"] });
    },
    onError: (err) => toast.error(err instanceof ApiClientError ? err.message : "Update failed"),
  });

  return (
    <div>
      <h2 className="font-display text-2xl">Fulfillment</h2>
      <p className="mt-1 text-sm text-muted">PUT /api/v1/orders/{"{id}"} is idempotent — repeating the same status is a no-op.</p>
      <div className="mt-6 overflow-x-auto rounded-xl bg-surface ring-1 ring-border">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="border-b border-border text-xs uppercase tracking-[0.12em] text-faint">
            <tr>
              <th className="px-4 py-3 font-medium">ID</th>
              <th className="px-4 py-3 font-medium">When</th>
              <th className="px-4 py-3 font-medium">Ship to</th>
              <th className="px-4 py-3 font-medium">Total</th>
              <th className="px-4 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {(orders.data?.data ?? []).length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-muted">
                  No orders yet.
                </td>
              </tr>
            )}
            {(orders.data?.data ?? []).map((order) => (
              <tr key={order.id} className="border-t border-border">
                <td className="px-4 py-3 tabular-nums">#{order.id}</td>
                <td className="px-4 py-3 text-muted">{formatDate(order.created_at)}</td>
                <td className="px-4 py-3">
                  {order.shipping_name}
                  <span className="block text-xs text-faint">{order.shipping_city}</span>
                </td>
                <td className="px-4 py-3 tabular-nums">{formatMoney(order.total)}</td>
                <td className="px-4 py-3">
                  <select
                    value={order.status}
                    onChange={(e) => mutate.mutate({ id: order.id, status: e.target.value })}
                    className="h-9 rounded-md border border-border bg-bg px-2 text-xs uppercase tracking-[0.12em]"
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
