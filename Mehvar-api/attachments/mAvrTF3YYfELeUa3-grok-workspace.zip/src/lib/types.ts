export type Role = "CUSTOMER" | "ADMIN";

export type Category = {
  id: number;
  slug: string;
  name: string;
  description: string;
  image_url: string;
  created_at: string;
  updated_at: string;
};

export type Product = {
  id: number;
  title: string;
  slug: string;
  description: string;
  price: number;
  compare_at_price: number | null;
  stock: number;
  category_id: number;
  category: string;
  image_url: string;
  gallery: string[];
  brand: string;
  sku: string;
  rating: number;
  review_count: number;
  featured: boolean;
  created_at: string;
  updated_at: string;
};

export type ProductPatch = Partial<Product>;

export type Paginated<T> = {
  data: T[];
  meta: {
    page: number;
    limit: number;
    total: number;
    total_pages: number;
  };
};

export type OrderStatus =
  | "pending"
  | "paid"
  | "packed"
  | "shipped"
  | "delivered"
  | "cancelled";

export type OrderItem = {
  id: number;
  order_id: number;
  product_id: number;
  title: string;
  unit_price: number;
  quantity: number;
  line_total: number;
};

export type Order = {
  id: number;
  user_id: string;
  status: OrderStatus;
  total: number;
  shipping_name: string;
  shipping_address: string;
  shipping_city: string;
  shipping_phone: string;
  notes: string;
  created_at: string;
  updated_at: string;
  items: OrderItem[];
};

export type ApiErrorBody = {
  error_code: string;
  message: string;
  timestamp: string;
  path: string;
};

export type InventoryRow = {
  id: number;
  title: string;
  sku: string;
  stock: number;
  category: string;
  price: number;
};

export type MeResponse = {
  id: string;
  email: string | null;
  role: Role;
  full_name: string | null;
};

export const PRODUCT_FIELDS = [
  "id",
  "title",
  "slug",
  "description",
  "price",
  "compare_at_price",
  "stock",
  "category_id",
  "category",
  "image_url",
  "gallery",
  "brand",
  "sku",
  "rating",
  "review_count",
  "featured",
  "created_at",
  "updated_at",
] as const;

export type ProductField = (typeof PRODUCT_FIELDS)[number];
