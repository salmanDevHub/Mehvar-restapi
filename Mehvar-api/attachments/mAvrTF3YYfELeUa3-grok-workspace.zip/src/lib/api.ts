import { getBearerToken } from "@/lib/auth/client";
import type { ApiErrorBody, Category, InventoryRow, MeResponse, Order, Paginated, Product } from "@/lib/types";

export class ApiClientError extends Error {
  readonly error_code: string;
  readonly status: number;
  readonly path: string;
  readonly timestamp: string;

  constructor(body: Partial<ApiErrorBody> & { message?: string }, status: number, fallbackPath: string) {
    super(body.message ?? "Request failed");
    this.name = "ApiClientError";
    this.error_code = body.error_code ?? "ERROR";
    this.status = status;
    this.path = body.path ?? fallbackPath;
    this.timestamp = body.timestamp ?? new Date().toISOString();
  }
}

type Init = RequestInit & { idempotencyKey?: string };

export async function api<T>(path: string, init: Init = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("Accept", "application/json");
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const token = getBearerToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (init.idempotencyKey) headers.set("Idempotency-Key", init.idempotencyKey);

  const res = await fetch(path, {
    ...init,
    headers,
    credentials: "include",
  });

  if (res.status === 204) return undefined as T;

  const payload = await res.json().catch(() => null);
  if (!res.ok) {
    throw new ApiClientError((payload ?? {}) as ApiErrorBody, res.status, path);
  }
  return payload as T;
}

export function listProducts(params: Record<string, string | number | boolean | undefined | null> = {}) {
  const qs = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === "") continue;
    qs.set(key, String(value));
  }
  const suffix = qs.toString() ? `?${qs}` : "";
  return api<Paginated<Product>>(`/api/v1/products${suffix}`);
}

export function getProduct(id: number, fields?: string) {
  const suffix = fields ? `?fields=${encodeURIComponent(fields)}` : "";
  return api<Partial<Product>>(`/api/v1/products/${id}${suffix}`);
}

export function createProduct(body: unknown) {
  return api<Product>("/api/v1/products", { method: "POST", body: JSON.stringify(body) });
}

export function updateProduct(id: number, body: unknown) {
  return api<Product>(`/api/v1/products/${id}`, { method: "PUT", body: JSON.stringify(body) });
}

export function deleteProduct(id: number) {
  return api<void>(`/api/v1/products/${id}`, { method: "DELETE" });
}

export function listCategories() {
  return api<Category[]>("/api/v1/categories");
}

export function createCategory(body: unknown) {
  return api<Category>("/api/v1/categories", { method: "POST", body: JSON.stringify(body) });
}

export function updateCategory(id: number, body: unknown) {
  return api<Category>(`/api/v1/categories/${id}`, { method: "PUT", body: JSON.stringify(body) });
}

export function deleteCategory(id: number) {
  return api<void>(`/api/v1/categories/${id}`, { method: "DELETE" });
}

export function listOrders(params: Record<string, string | number | undefined> = {}) {
  const qs = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === "") continue;
    qs.set(key, String(value));
  }
  const suffix = qs.toString() ? `?${qs}` : "";
  return api<Paginated<Order>>(`/api/v1/orders${suffix}`);
}

export function getOrder(id: number) {
  return api<Order>(`/api/v1/orders/${id}`);
}

export function createOrder(body: unknown, idempotencyKey: string) {
  return api<Order>("/api/v1/orders", {
    method: "POST",
    body: JSON.stringify(body),
    idempotencyKey,
  });
}

export function updateOrderStatus(id: number, status: string) {
  return api<Order>(`/api/v1/orders/${id}`, {
    method: "PUT",
    body: JSON.stringify({ status }),
  });
}

export function getMe() {
  return api<MeResponse>("/api/v1/auth/me");
}

export function getInventory() {
  return api<InventoryRow[]>("/api/v1/inventory");
}
