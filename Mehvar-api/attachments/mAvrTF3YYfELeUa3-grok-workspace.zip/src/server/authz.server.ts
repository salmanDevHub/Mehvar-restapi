import { auth } from "@/lib/auth/server";
import { getSql } from "@/lib/db";
import type { MeResponse, Role } from "@/lib/types";
import { ApiError } from "./errors";

export type SessionUser = { id: string; email: string | null };

export async function sessionFromRequest(request: Request): Promise<SessionUser | null> {
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session?.user) return null;
  return { id: session.user.id, email: session.user.email ?? null };
}

export async function requireUser(request: Request): Promise<SessionUser> {
  const user = await sessionFromRequest(request);
  if (!user) {
    throw new ApiError(401, "UNAUTHORIZED", "Sign in is required to access this resource.");
  }
  return user;
}

export async function ensureProfile(userId: string, email: string | null): Promise<{ role: Role; full_name: string | null }> {
  const sql = await getSql();
  const existing = await sql<{ role: Role; full_name: string | null }>`
    select role, full_name from profiles where user_id = ${userId}
  `;
  if (existing[0]) return existing[0];

  const admins = await sql<{ n: number }>`select count(*)::int as n from profiles where role = 'ADMIN'`;
  const role: Role = (admins[0]?.n ?? 0) === 0 ? "ADMIN" : "CUSTOMER";
  const fullName = email ? email.split("@")[0] : null;
  await sql`
    insert into profiles (user_id, role, full_name)
    values (${userId}, ${role}, ${fullName})
  `;
  return { role, full_name: fullName };
}

export async function requireAdmin(request: Request): Promise<SessionUser & { role: Role }> {
  const user = await requireUser(request);
  const profile = await ensureProfile(user.id, user.email);
  if (profile.role !== "ADMIN") {
    throw new ApiError(403, "FORBIDDEN", "Admin privileges are required for this action.");
  }
  return { ...user, role: profile.role };
}

export async function mePayload(request: Request): Promise<MeResponse> {
  const user = await requireUser(request);
  const profile = await ensureProfile(user.id, user.email);
  return {
    id: user.id,
    email: user.email,
    role: profile.role,
    full_name: profile.full_name,
  };
}
