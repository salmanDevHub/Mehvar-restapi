import { getSql } from "@/lib/db";
import type { Order, OrderStatus } from "@/lib/types";
import { z } from "zod";
import { ApiError } from "./errors";
import { hashRequest } from "./idempotency";
import { mapOrder, mapOrderItem } from "./mappers";
import { pageMeta, parsePage } from "./pagination";

const createSchema = z.object({
  shipping_name: z.string().trim().min(2, "Full name is required.").max(120),
  shipping_address: z.string().trim().min(6, "A street address is required.").max(240),
  shipping_city: z.string().trim().min(2, "City is required.").max(80),
  shipping_phone: z.string().trim().min(7, "A phone number is required.").max(30),
  notes: z.string().trim().max(400).optional(),
  items: z
    .array(
      z.object({
        product_id: z.coerce.number().int().positive(),
        quantity: z.coerce.number().int().min(1).max(20),
      }),
    )
    .min(1, "An order must contain at least one item."),
});

const STATUSES = ["pending", "paid", "packed", "shipped", "delivered", "cancelled"] as const;

async function loadOrder(id: number): Promise<Order> {
  const sql = await getSql();
  const rows = await sql`
    select id, user_id, status, total, shipping_name, shipping_address, shipping_city,
           shipping_phone, notes, created_at, updated_at
    from orders where id = ${id}
  `;
  if (!rows[0]) throw new ApiError(404, "ORDER_NOT_FOUND", `Order with ID ${id} was not found.`);
  const items = await sql`
    select id, order_id, product_id, title, unit_price, quantity, line_total
    from order_items where order_id = ${id} order by id asc
  `;
  return mapOrder(rows[0], items.map(mapOrderItem));
}

export async function listOrdersForUser(userId: string, url: URL, isAdmin: boolean) {
  const sql = await getSql();
  const { page, limit, offset } = parsePage(url.searchParams, { limit: 10 });
  const status = url.searchParams.get("status");

  const clauses: string[] = [];
  const params: unknown[] = [];
  const push = (frag: string, value: unknown) => {
    params.push(value);
    clauses.push(frag.replace("?", `$${params.length}`));
  };

  if (!isAdmin) push("user_id = ?", userId);
  if (status) {
    if (!STATUSES.includes(status as OrderStatus)) {
      throw new ApiError(400, "VALIDATION_ERROR", `Unknown status. Allowed: ${STATUSES.join(", ")}.`);
    }
    push("status = ?", status);
  }

  const where = clauses.length ? `where ${clauses.join(" and ")}` : "";
  const count = await sql.query<{ n: number }>(`select count(*)::int as n from orders ${where}`, params);
  const total = count[0]?.n ?? 0;
  const rows = await sql.query<{ id: number }>(
    `select id from orders ${where} order by created_at desc, id desc limit $${params.length + 1} offset $${params.length + 2}`,
    [...params, limit, offset],
  );
  const data = [];
  for (const row of rows) data.push(await loadOrder(Number(row.id)));
  return { data, meta: pageMeta(total, page, limit) };
}

export async function getOrderForUser(id: number, userId: string, isAdmin: boolean) {
  const order = await loadOrder(id);
  if (!isAdmin && order.user_id !== userId) {
    throw new ApiError(404, "ORDER_NOT_FOUND", `Order with ID ${id} was not found.`);
  }
  return order;
}

type IdempotencyRow = {
  key: string;
  user_id: string;
  request_hash: string;
  response_status: number;
  response_body: unknown;
};

export async function createOrder(userId: string, body: unknown, idempotencyKey: string | null) {
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    throw new ApiError(400, "VALIDATION_ERROR", parsed.error.issues[0]?.message ?? "Invalid order payload.");
  }
  const data = parsed.data;
  const sql = await getSql();
  const requestHash = hashRequest(userId, data);

  if (idempotencyKey) {
    if (idempotencyKey.length < 8 || idempotencyKey.length > 128) {
      throw new ApiError(400, "INVALID_IDEMPOTENCY_KEY", "Idempotency-Key must be between 8 and 128 characters.");
    }
    const existing = await sql.query<IdempotencyRow>(
      `select key, user_id, request_hash, response_status, response_body from idempotency_keys where key = $1`,
      [idempotencyKey],
    );
    if (existing[0]) {
      if (existing[0].user_id !== userId) {
        throw new ApiError(409, "IDEMPOTENCY_KEY_REUSED", "This Idempotency-Key belongs to another account.");
      }
      if (existing[0].request_hash !== requestHash) {
        throw new ApiError(
          409,
          "IDEMPOTENCY_KEY_CONFLICT",
          "This Idempotency-Key was already used with a different request body.",
        );
      }
      return {
        replayed: true,
        status: existing[0].response_status,
        body: existing[0].response_body,
      };
    }

    const claimed = await sql.query<{ key: string }>(
      `insert into idempotency_keys (key, user_id, request_hash, response_status, response_body)
       values ($1, $2, $3, 0, '{}'::jsonb)
       on conflict (key) do nothing
       returning key`,
      [idempotencyKey, userId, requestHash],
    );
    if (!claimed[0]) {
      const again = await sql.query<IdempotencyRow>(
        `select key, user_id, request_hash, response_status, response_body from idempotency_keys where key = $1`,
        [idempotencyKey],
      );
      if (again[0] && again[0].request_hash === requestHash) {
        return { replayed: true, status: again[0].response_status, body: again[0].response_body };
      }
      throw new ApiError(409, "IDEMPOTENCY_KEY_CONFLICT", "This Idempotency-Key is already in use.");
    }
  }

  try {
    const order = await placeOrder(userId, data);
    if (idempotencyKey) {
      await sql.query(
        `update idempotency_keys set response_status = 201, response_body = $2::jsonb where key = $1`,
        [idempotencyKey, JSON.stringify(order)],
      );
    }
    return { replayed: false, status: 201, body: order };
  } catch (err) {
    if (idempotencyKey) {
      await sql.query(`delete from idempotency_keys where key = $1 and response_status = 0`, [idempotencyKey]);
    }
    throw err;
  }
}

async function placeOrder(
  userId: string,
  data: z.infer<typeof createSchema>,
): Promise<Order> {
  const sql = await getSql();
  const merged = new Map<number, number>();
  for (const item of data.items) {
    merged.set(item.product_id, (merged.get(item.product_id) ?? 0) + item.quantity);
  }

  const lines: { product_id: number; title: string; unit_price: number; quantity: number; line_total: number }[] = [];
  let total = 0;

  for (const [productId, quantity] of merged) {
    const rows = await sql<{ id: number; title: string; price: unknown; stock: number }>`
      select id, title, price, stock from products where id = ${productId}
    `;
    const product = rows[0];
    if (!product) {
      throw new ApiError(400, "PRODUCT_NOT_FOUND", `Product with ID ${productId} was not found.`);
    }
    const stock = Number(product.stock);
    if (stock < quantity) {
      throw new ApiError(
        409,
        "INSUFFICIENT_STOCK",
        `${product.title} only has ${stock} unit${stock === 1 ? "" : "s"} remaining.`,
      );
    }
    const unit = Number(product.price);
    const lineTotal = Math.round(unit * quantity * 100) / 100;
    total += lineTotal;
    lines.push({
      product_id: productId,
      title: product.title,
      unit_price: unit,
      quantity,
      line_total: lineTotal,
    });
  }

  total = Math.round(total * 100) / 100;
  const inserted = await sql<{ id: number }>`
    insert into orders (
      user_id, status, total, shipping_name, shipping_address, shipping_city, shipping_phone, notes
    ) values (
      ${userId}, 'pending', ${total}, ${data.shipping_name}, ${data.shipping_address},
      ${data.shipping_city}, ${data.shipping_phone}, ${data.notes ?? ""}
    )
    returning id
  `;
  const orderId = Number(inserted[0].id);

  for (const line of lines) {
    await sql`
      insert into order_items (order_id, product_id, title, unit_price, quantity, line_total)
      values (${orderId}, ${line.product_id}, ${line.title}, ${line.unit_price}, ${line.quantity}, ${line.line_total})
    `;
    const updated = await sql<{ id: number }>`
      update products
      set stock = stock - ${line.quantity}, updated_at = now()
      where id = ${line.product_id} and stock >= ${line.quantity}
      returning id
    `;
    if (!updated[0]) {
      throw new ApiError(409, "INSUFFICIENT_STOCK", `${line.title} no longer has enough stock.`);
    }
  }

  return loadOrder(orderId);
}

export async function updateOrderStatus(id: number, body: unknown) {
  const parsed = z.object({ status: z.enum(STATUSES) }).safeParse(body);
  if (!parsed.success) {
    throw new ApiError(
      400,
      "VALIDATION_ERROR",
      `Status must be one of: ${STATUSES.join(", ")}.`,
    );
  }
  const sql = await getSql();
  const existing = await sql<{ id: number; status: string }>`select id, status from orders where id = ${id}`;
  if (!existing[0]) throw new ApiError(404, "ORDER_NOT_FOUND", `Order with ID ${id} was not found.`);
  await sql`update orders set status = ${parsed.data.status}, updated_at = now() where id = ${id}`;
  return loadOrder(id);
}
