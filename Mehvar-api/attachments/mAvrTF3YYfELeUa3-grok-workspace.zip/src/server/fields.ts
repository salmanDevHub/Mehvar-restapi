import { PRODUCT_FIELDS, type ProductField } from "../lib/types.ts";
import { ApiError } from "./errors.ts";

export function parseFields(
  raw: string | null,
  allowed: readonly string[] = PRODUCT_FIELDS,
): string[] | null {
  if (raw == null) return null;
  const trimmed = raw.trim();
  if (!trimmed) {
    throw new ApiError(
      400,
      "INVALID_FIELDS",
      "The fields parameter cannot be empty. Pass a comma-separated list such as title,price.",
    );
  }
  const requested = trimmed
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);
  if (requested.length === 0) {
    throw new ApiError(
      400,
      "INVALID_FIELDS",
      "The fields parameter cannot be empty. Pass a comma-separated list such as title,price.",
    );
  }
  const allowedSet = new Set(allowed);
  const invalid = requested.filter((field) => !allowedSet.has(field));
  if (invalid.length > 0) {
    throw new ApiError(
      400,
      "INVALID_FIELDS",
      `Unknown field${invalid.length > 1 ? "s" : ""}: ${invalid.join(", ")}. Allowed fields: ${allowed.join(", ")}.`,
    );
  }
  return requested;
}

export function projectRow<T extends Record<string, unknown>>(
  row: T,
  fields: string[] | null,
): Record<string, unknown> {
  if (!fields) return row;
  const out: Record<string, unknown> = {};
  for (const field of fields) {
    out[field] = row[field];
  }
  return out;
}

export function isProductField(value: string): value is ProductField {
  return (PRODUCT_FIELDS as readonly string[]).includes(value);
}
