import type { Category, InventoryRow, Order, OrderItem, OrderStatus, Product } from "@/lib/types";

function num(value: unknown, fallback = 0): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value !== "") {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return fallback;
}

function numOrNull(value: unknown): number | null {
  if (value == null || value === "") return null;
  const n = num(value, Number.NaN);
  return Number.isFinite(n) ? n : null;
}

function iso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return new Date().toISOString();
}

function strArr(value: unknown): string[] {
  if (Array.isArray(value)) return value.filter((v) => typeof v === "string") as string[];
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.filter((v) => typeof v === "string") : [];
    } catch {
      return [];
    }
  }
  return [];
}

export type ProductRow = {
  id: number;
  title: string;
  slug: string;
  description: string;
  price: unknown;
  compare_at_price: unknown;
  stock: number;
  category_id: number;
  category?: string;
  category_name?: string;
  image_url: string;
  gallery: unknown;
  brand: string;
  sku: string;
  rating: unknown;
  review_count: number;
  featured: boolean;
  created_at: unknown;
  updated_at: unknown;
};

export function mapProduct(row: ProductRow): Product {
  return {
    id: Number(row.id),
    title: row.title,
    slug: row.slug,
    description: row.description,
    price: num(row.price),
    compare_at_price: numOrNull(row.compare_at_price),
    stock: Number(row.stock),
    category_id: Number(row.category_id),
    category: row.category ?? row.category_name ?? "",
    image_url: row.image_url,
    gallery: strArr(row.gallery),
    brand: row.brand ?? "",
    sku: row.sku,
    rating: num(row.rating),
    review_count: Number(row.review_count ?? 0),
    featured: Boolean(row.featured),
    created_at: iso(row.created_at),
    updated_at: iso(row.updated_at),
  };
}

export function mapCategory(row: {
  id: number;
  slug: string;
  name: string;
  description: string;
  image_url: string;
  created_at: unknown;
  updated_at: unknown;
}): Category {
  return {
    id: Number(row.id),
    slug: row.slug,
    name: row.name,
    description: row.description,
    image_url: row.image_url,
    created_at: iso(row.created_at),
    updated_at: iso(row.updated_at),
  };
}

export function mapOrderItem(row: {
  id: number;
  order_id: number;
  product_id: number;
  title: string;
  unit_price: unknown;
  quantity: number;
  line_total: unknown;
}): OrderItem {
  return {
    id: Number(row.id),
    order_id: Number(row.order_id),
    product_id: Number(row.product_id),
    title: row.title,
    unit_price: num(row.unit_price),
    quantity: Number(row.quantity),
    line_total: num(row.line_total),
  };
}

export function mapOrder(
  row: {
    id: number;
    user_id: string;
    status: string;
    total: unknown;
    shipping_name: string;
    shipping_address: string;
    shipping_city: string;
    shipping_phone: string;
    notes: string;
    created_at: unknown;
    updated_at: unknown;
  },
  items: OrderItem[],
): Order {
  return {
    id: Number(row.id),
    user_id: row.user_id,
    status: row.status as OrderStatus,
    total: num(row.total),
    shipping_name: row.shipping_name,
    shipping_address: row.shipping_address,
    shipping_city: row.shipping_city,
    shipping_phone: row.shipping_phone ?? "",
    notes: row.notes ?? "",
    created_at: iso(row.created_at),
    updated_at: iso(row.updated_at),
    items,
  };
}

export function mapInventory(row: {
  id: number;
  title: string;
  sku: string;
  stock: number;
  category: string;
  price: unknown;
}): InventoryRow {
  return {
    id: Number(row.id),
    title: row.title,
    sku: row.sku,
    stock: Number(row.stock),
    category: row.category,
    price: num(row.price),
  };
}
