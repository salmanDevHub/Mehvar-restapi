import { getSql } from "@/lib/db";
import { slugify } from "@/lib/utils";
import { z } from "zod";
import { ApiError } from "./errors";
import { mapCategory } from "./mappers";

const writeSchema = z.object({
  name: z.string().trim().min(2).max(80),
  description: z.string().trim().max(400).optional(),
  image_url: z.string().trim().url().max(500).optional(),
  slug: z.string().trim().max(80).optional(),
});

function parseWrite(body: unknown) {
  const parsed = writeSchema.safeParse(body);
  if (!parsed.success) {
    throw new ApiError(400, "VALIDATION_ERROR", parsed.error.issues[0]?.message ?? "Invalid category payload.");
  }
  return parsed.data;
}

export async function listCategories() {
  const sql = await getSql();
  const rows = await sql`
    select id, slug, name, description, image_url, created_at, updated_at
    from categories
    order by name asc
  `;
  return rows.map(mapCategory);
}

export async function getCategory(id: number) {
  const sql = await getSql();
  const rows = await sql`
    select id, slug, name, description, image_url, created_at, updated_at
    from categories where id = ${id}
  `;
  if (!rows[0]) throw new ApiError(404, "CATEGORY_NOT_FOUND", `Category with ID ${id} was not found.`);
  return mapCategory(rows[0]);
}

export async function createCategory(body: unknown) {
  const data = parseWrite(body);
  const sql = await getSql();
  const slug = slugify(data.slug || data.name);
  try {
    const rows = await sql`
      insert into categories (slug, name, description, image_url)
      values (${slug}, ${data.name}, ${data.description ?? ""}, ${data.image_url ?? ""})
      returning id, slug, name, description, image_url, created_at, updated_at
    `;
    return mapCategory(rows[0]);
  } catch (err) {
    const message = err instanceof Error ? err.message : "";
    if (message.toLowerCase().includes("unique") || message.toLowerCase().includes("duplicate")) {
      throw new ApiError(409, "CONFLICT", "A category with this slug already exists.");
    }
    throw err;
  }
}

export async function updateCategory(id: number, body: unknown) {
  if (!Number.isInteger(id) || id < 1) {
    throw new ApiError(400, "VALIDATION_ERROR", "Category ID must be a positive integer.");
  }
  const data = parseWrite(body);
  const sql = await getSql();
  const existing = await sql`select id from categories where id = ${id}`;
  if (!existing[0]) throw new ApiError(404, "CATEGORY_NOT_FOUND", `Category with ID ${id} was not found.`);
  const slug = slugify(data.slug || data.name);
  const rows = await sql`
    update categories
    set slug = ${slug}, name = ${data.name}, description = ${data.description ?? ""},
        image_url = ${data.image_url ?? ""}, updated_at = now()
    where id = ${id}
    returning id, slug, name, description, image_url, created_at, updated_at
  `;
  return mapCategory(rows[0]);
}

export async function deleteCategory(id: number) {
  if (!Number.isInteger(id) || id < 1) {
    throw new ApiError(400, "VALIDATION_ERROR", "Category ID must be a positive integer.");
  }
  const sql = await getSql();
  const existing = await sql`select id from categories where id = ${id}`;
  if (!existing[0]) throw new ApiError(404, "CATEGORY_NOT_FOUND", `Category with ID ${id} was not found.`);
  const used = await sql<{ n: number }>`select count(*)::int as n from products where category_id = ${id}`;
  if ((used[0]?.n ?? 0) > 0) {
    throw new ApiError(409, "CATEGORY_IN_USE", "This category still has products and cannot be deleted.");
  }
  await sql`delete from categories where id = ${id}`;
}
