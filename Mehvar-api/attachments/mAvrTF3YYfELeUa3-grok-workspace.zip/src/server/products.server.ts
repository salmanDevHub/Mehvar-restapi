import { getSql } from "@/lib/db";
import { slugify } from "@/lib/utils";
import type { Product } from "@/lib/types";
import { z } from "zod";
import { ApiError } from "./errors";
import { parseFields, projectRow } from "./fields";
import { mapProduct, type ProductRow } from "./mappers";
import { pageMeta, parsePage } from "./pagination";

const PRODUCT_SELECT = `
  p.id, p.title, p.slug, p.description, p.price, p.compare_at_price, p.stock,
  p.category_id, c.name as category, p.image_url, p.gallery, p.brand, p.sku,
  p.rating, p.review_count, p.featured, p.created_at, p.updated_at
`;

const productWriteSchema = z.object({
  title: z.string().trim().min(2, "Title must be at least 2 characters.").max(160),
  description: z.string().trim().min(12, "Description must be at least 12 characters.").max(4000),
  price: z.coerce.number().finite().min(0, "Price cannot be negative."),
  compare_at_price: z.coerce.number().finite().min(0).nullable().optional(),
  stock: z.coerce.number().int().min(0, "Stock cannot be negative."),
  category_id: z.coerce.number().int().positive("A valid category is required."),
  image_url: z.string().trim().url("Image URL must be a valid URL.").max(500),
  gallery: z.array(z.string().url()).max(8).optional(),
  brand: z.string().trim().max(80).optional(),
  sku: z.string().trim().min(3).max(40).optional(),
  featured: z.boolean().optional(),
});

export type ProductWrite = z.infer<typeof productWriteSchema>;

export function parseProductWrite(body: unknown): ProductWrite {
  const parsed = productWriteSchema.safeParse(body);
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    throw new ApiError(400, "VALIDATION_ERROR", issue?.message ?? "Invalid product payload.");
  }
  return parsed.data;
}

async function uniqueSlug(base: string, excludeId?: number) {
  const sql = await getSql();
  let slug = slugify(base) || "product";
  let n = 0;
  while (true) {
    const candidate = n === 0 ? slug : `${slug}-${n}`;
    const rows = excludeId
      ? await sql<{ id: number }>`select id from products where slug = ${candidate} and id <> ${excludeId}`
      : await sql<{ id: number }>`select id from products where slug = ${candidate}`;
    if (rows.length === 0) return candidate;
    n += 1;
  }
}

async function uniqueSku(title: string, excludeId?: number) {
  const sql = await getSql();
  const stem = slugify(title).replace(/-/g, "").slice(0, 8).toUpperCase() || "SKU";
  for (let i = 0; i < 20; i += 1) {
    const sku = `${stem}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    const rows = excludeId
      ? await sql<{ id: number }>`select id from products where sku = ${sku} and id <> ${excludeId}`
      : await sql<{ id: number }>`select id from products where sku = ${sku}`;
    if (rows.length === 0) return sku;
  }
  return `${stem}-${Date.now().toString(36).toUpperCase()}`;
}

export async function listProducts(url: URL) {
  const sql = await getSql();
  const { page, limit, offset } = parsePage(url.searchParams);
  const fields = parseFields(url.searchParams.get("fields"));

  const categoryIdRaw = url.searchParams.get("category_id");
  const categorySlug = url.searchParams.get("category");
  const search = url.searchParams.get("search")?.trim() ?? "";
  const featuredRaw = url.searchParams.get("featured");
  const minPriceRaw = url.searchParams.get("min_price");
  const maxPriceRaw = url.searchParams.get("max_price");

  const clauses: string[] = ["1=1"];
  const params: unknown[] = [];
  const push = (sqlFrag: string, value: unknown) => {
    params.push(value);
    clauses.push(sqlFrag.replace("?", `$${params.length}`));
  };

  if (categoryIdRaw) {
    const id = Number(categoryIdRaw);
    if (!Number.isInteger(id) || id < 1) {
      throw new ApiError(400, "VALIDATION_ERROR", "category_id must be a positive integer.");
    }
    push("p.category_id = ?", id);
  } else if (categorySlug) {
    push("c.slug = ?", categorySlug);
  }

  if (search) {
    params.push(`%${search.toLowerCase()}%`);
    const p = `$${params.length}`;
    clauses.push(`(lower(p.title) like ${p} or lower(p.description) like ${p} or lower(p.brand) like ${p})`);
  }

  if (featuredRaw === "true" || featuredRaw === "1") {
    clauses.push("p.featured = true");
  } else if (featuredRaw === "false" || featuredRaw === "0") {
    clauses.push("p.featured = false");
  }

  if (minPriceRaw) {
    const min = Number(minPriceRaw);
    if (!Number.isFinite(min) || min < 0) {
      throw new ApiError(400, "VALIDATION_ERROR", "min_price must be a non-negative number.");
    }
    push("p.price >= ?", min);
  }
  if (maxPriceRaw) {
    const max = Number(maxPriceRaw);
    if (!Number.isFinite(max) || max < 0) {
      throw new ApiError(400, "VALIDATION_ERROR", "max_price must be a non-negative number.");
    }
    push("p.price <= ?", max);
  }

  const where = clauses.join(" and ");
  const countSql = `select count(*)::int as n from products p join categories c on c.id = p.category_id where ${where}`;
  const countRows = await sql.query<{ n: number }>(countSql, params);
  const total = countRows[0]?.n ?? 0;

  const dataSql = `
    select ${PRODUCT_SELECT}
    from products p
    join categories c on c.id = p.category_id
    where ${where}
    order by p.featured desc, p.created_at desc, p.id desc
    limit $${params.length + 1} offset $${params.length + 2}
  `;
  const rows = await sql.query<ProductRow>(dataSql, [...params, limit, offset]);
  const data = rows.map((row) => projectRow(mapProduct(row) as unknown as Record<string, unknown>, fields));
  return { data, meta: pageMeta(total, page, limit) };
}

export async function getProduct(id: number, fieldsRaw: string | null) {
  if (!Number.isInteger(id) || id < 1) {
    throw new ApiError(400, "VALIDATION_ERROR", "Product ID must be a positive integer.");
  }
  const fields = parseFields(fieldsRaw);
  const sql = await getSql();
  const rows = await sql.query<ProductRow>(
    `select ${PRODUCT_SELECT} from products p join categories c on c.id = p.category_id where p.id = $1`,
    [id],
  );
  if (!rows[0]) {
    throw new ApiError(404, "PRODUCT_NOT_FOUND", `Product with ID ${id} was not found.`);
  }
  return projectRow(mapProduct(rows[0]) as unknown as Record<string, unknown>, fields);
}

export async function createProduct(body: unknown): Promise<Product> {
  const data = parseProductWrite(body);
  const sql = await getSql();
  const cats = await sql<{ id: number }>`select id from categories where id = ${data.category_id}`;
  if (!cats[0]) throw new ApiError(400, "VALIDATION_ERROR", "The specified category does not exist.");

  const slug = await uniqueSlug(data.title);
  const sku = data.sku?.trim() || (await uniqueSku(data.title));
  const gallery = JSON.stringify(data.gallery ?? []);
  const compare = data.compare_at_price ?? null;
  const brand = data.brand ?? "";
  const featured = data.featured ?? false;

  try {
    const rows = await sql.query<ProductRow>(
      `insert into products (
         title, slug, description, price, compare_at_price, stock, category_id,
         image_url, gallery, brand, sku, featured
       ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,$10,$11,$12)
       returning id`,
      [
        data.title,
        slug,
        data.description,
        data.price,
        compare,
        data.stock,
        data.category_id,
        data.image_url,
        gallery,
        brand,
        sku,
        featured,
      ],
    );
    const id = Number(rows[0]?.id);
    return (await getProduct(id, null)) as unknown as Product;
  } catch (err) {
    const message = err instanceof Error ? err.message : "";
    if (message.toLowerCase().includes("unique") || message.toLowerCase().includes("duplicate")) {
      throw new ApiError(409, "CONFLICT", "A product with this SKU or slug already exists.");
    }
    throw err;
  }
}

export async function updateProduct(id: number, body: unknown): Promise<Product> {
  if (!Number.isInteger(id) || id < 1) {
    throw new ApiError(400, "VALIDATION_ERROR", "Product ID must be a positive integer.");
  }
  const data = parseProductWrite(body);
  const sql = await getSql();
  const existing = await sql<{ id: number }>`select id from products where id = ${id}`;
  if (!existing[0]) {
    throw new ApiError(404, "PRODUCT_NOT_FOUND", `Product with ID ${id} was not found.`);
  }
  const cats = await sql<{ id: number }>`select id from categories where id = ${data.category_id}`;
  if (!cats[0]) throw new ApiError(400, "VALIDATION_ERROR", "The specified category does not exist.");

  const slug = await uniqueSlug(data.title, id);
  const sku = data.sku?.trim() || (await uniqueSku(data.title, id));
  const gallery = JSON.stringify(data.gallery ?? []);
  const compare = data.compare_at_price ?? null;
  const brand = data.brand ?? "";
  const featured = data.featured ?? false;

  await sql.query(
    `update products set
       title = $1, slug = $2, description = $3, price = $4, compare_at_price = $5,
       stock = $6, category_id = $7, image_url = $8, gallery = $9::jsonb, brand = $10,
       sku = $11, featured = $12, updated_at = now()
     where id = $13`,
    [
      data.title,
      slug,
      data.description,
      data.price,
      compare,
      data.stock,
      data.category_id,
      data.image_url,
      gallery,
      brand,
      sku,
      featured,
      id,
    ],
  );
  return (await getProduct(id, null)) as unknown as Product;
}

export async function deleteProduct(id: number) {
  if (!Number.isInteger(id) || id < 1) {
    throw new ApiError(400, "VALIDATION_ERROR", "Product ID must be a positive integer.");
  }
  const sql = await getSql();
  const existing = await sql<{ id: number }>`select id from products where id = ${id}`;
  if (!existing[0]) {
    throw new ApiError(404, "PRODUCT_NOT_FOUND", `Product with ID ${id} was not found.`);
  }
  const used = await sql<{ n: number }>`select count(*)::int as n from order_items where product_id = ${id}`;
  if ((used[0]?.n ?? 0) > 0) {
    throw new ApiError(
      409,
      "PRODUCT_IN_USE",
      "This product appears on existing orders and cannot be deleted. Reduce stock to zero instead.",
    );
  }
  await sql`delete from products where id = ${id}`;
}

export async function listInventory() {
  const sql = await getSql();
  const rows = await sql.query<{
    id: number;
    title: string;
    sku: string;
    stock: number;
    category: string;
    price: unknown;
  }>(
    `select p.id, p.title, p.sku, p.stock, c.name as category, p.price
     from products p join categories c on c.id = p.category_id
     order by p.stock asc, p.title asc`,
  );
  return rows.map((row) => ({
    id: Number(row.id),
    title: row.title,
    sku: row.sku,
    stock: Number(row.stock),
    category: row.category,
    price: Number(row.price),
  }));
}
