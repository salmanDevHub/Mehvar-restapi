export class ApiError extends Error {
  readonly status: number;
  readonly code: string;

  constructor(status: number, code: string, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

export type ErrorBody = {
  error_code: string;
  message: string;
  timestamp: string;
  path: string;
};

export function errorBody(code: string, message: string, path: string): ErrorBody {
  return {
    error_code: code,
    message,
    timestamp: new Date().toISOString(),
    path,
  };
}

export function jsonError(status: number, code: string, message: string, path: string) {
  return Response.json(errorBody(code, message, path), { status });
}

export function errorResponse(err: unknown, path: string): Response {
  if (err instanceof ApiError) {
    return jsonError(err.status, err.code, err.message, path);
  }
  if (err && typeof err === "object" && "issues" in err) {
    const issues = (err as { issues: Array<{ message?: string; path?: unknown }> }).issues;
    const first = issues?.[0];
    const detail = first?.message ?? "Request validation failed.";
    return jsonError(400, "VALIDATION_ERROR", detail, path);
  }
  console.error("[mehvar] unhandled error", err);
  return jsonError(500, "INTERNAL_ERROR", "An unexpected error occurred.", path);
}

export function pathOf(request: Request) {
  try {
    return new URL(request.url).pathname;
  } catch {
    return "/api/v1";
  }
}
