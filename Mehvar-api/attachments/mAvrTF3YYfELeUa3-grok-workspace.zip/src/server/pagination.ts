import { ApiError } from "./errors.ts";

export type PageParams = {
  page: number;
  limit: number;
  offset: number;
};

export function parsePage(search: URLSearchParams, defaults?: { page?: number; limit?: number }): PageParams {
  const defaultPage = defaults?.page ?? 1;
  const defaultLimit = defaults?.limit ?? 12;
  const pageRaw = search.get("page");
  const limitRaw = search.get("limit") ?? search.get("page_size");

  const page = pageRaw == null || pageRaw === "" ? defaultPage : Number(pageRaw);
  const limit = limitRaw == null || limitRaw === "" ? defaultLimit : Number(limitRaw);

  if (!Number.isInteger(page) || page < 1) {
    throw new ApiError(400, "INVALID_PAGINATION", "Query parameter page must be a positive integer.");
  }
  if (!Number.isInteger(limit) || limit < 1) {
    throw new ApiError(400, "INVALID_PAGINATION", "Query parameter limit must be a positive integer.");
  }
  if (limit > 50) {
    throw new ApiError(400, "INVALID_PAGINATION", "Query parameter limit cannot exceed 50.");
  }
  return { page, limit, offset: (page - 1) * limit };
}

export function pageMeta(total: number, page: number, limit: number) {
  return {
    page,
    limit,
    total,
    total_pages: total === 0 ? 0 : Math.ceil(total / limit),
  };
}
