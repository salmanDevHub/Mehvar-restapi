import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ApiError, errorBody } from "./errors.ts";
import { parseFields, projectRow } from "./fields.ts";
import { pageMeta, parsePage } from "./pagination.ts";
import { hashRequest, stableStringify } from "./idempotency.ts";

describe("field selection", () => {
  it("returns null when fields is omitted", () => {
    assert.equal(parseFields(null), null);
  });

  it("parses a valid comma-separated list", () => {
    assert.deepEqual(parseFields("title,price"), ["title", "price"]);
  });

  it("rejects unknown fields with 400", () => {
    try {
      parseFields("title,vendor_secrets");
      assert.fail("expected ApiError");
    } catch (err) {
      assert.ok(err instanceof ApiError);
      assert.equal(err.status, 400);
      assert.equal(err.code, "INVALID_FIELDS");
    }
  });

  it("rejects an empty fields parameter", () => {
    try {
      parseFields("   ");
      assert.fail("expected ApiError");
    } catch (err) {
      assert.ok(err instanceof ApiError);
      assert.equal(err.code, "INVALID_FIELDS");
    }
  });

  it("projects only requested keys", () => {
    const row = { title: "Aurora", price: 189, description: "heavy" };
    assert.deepEqual(projectRow(row, ["title", "price"]), { title: "Aurora", price: 189 });
  });
});

describe("error schema", () => {
  it("emits error_code, message, timestamp, path", () => {
    const body = errorBody("PRODUCT_NOT_FOUND", "Product with ID 123 was not found.", "/api/v1/products/123");
    assert.equal(body.error_code, "PRODUCT_NOT_FOUND");
    assert.equal(body.message, "Product with ID 123 was not found.");
    assert.equal(body.path, "/api/v1/products/123");
    assert.ok(typeof body.timestamp === "string" && body.timestamp.includes("T"));
  });
});

describe("pagination", () => {
  it("applies defaults and computes offset", () => {
    const p = parsePage(new URLSearchParams());
    assert.deepEqual(p, { page: 1, limit: 12, offset: 0 });
  });

  it("accepts page and limit", () => {
    const p = parsePage(new URLSearchParams("page=2&limit=5"));
    assert.equal(p.offset, 5);
    assert.deepEqual(pageMeta(18, 2, 5), { page: 2, limit: 5, total: 18, total_pages: 4 });
  });

  it("rejects oversized pages", () => {
    try {
      parsePage(new URLSearchParams("limit=500"));
      assert.fail("expected ApiError");
    } catch (err) {
      assert.ok(err instanceof ApiError);
      assert.equal(err.status, 400);
    }
  });
});

describe("idempotency hashing", () => {
  it("is stable across key order", () => {
    const a = stableStringify({ b: 1, a: 2 });
    const b = stableStringify({ a: 2, b: 1 });
    assert.equal(a, b);
  });

  it("produces the same hash for the same order payload", () => {
    const payload = { items: [{ product_id: 1, quantity: 2 }], shipping_name: "Amina" };
    assert.equal(hashRequest("user-1", payload), hashRequest("user-1", payload));
    assert.notEqual(hashRequest("user-1", payload), hashRequest("user-2", payload));
  });
});
