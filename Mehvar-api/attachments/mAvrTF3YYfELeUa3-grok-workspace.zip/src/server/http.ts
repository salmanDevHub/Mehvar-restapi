import { ApiError, errorResponse, pathOf } from "./errors";

type HandlerCtx = {
  request: Request;
  params: Record<string, string>;
};

export function wrap(
  fn: (ctx: HandlerCtx) => Promise<Response>,
): (ctx: { request: Request; params?: Record<string, string> }) => Promise<Response> {
  return async ({ request, params }) => {
    try {
      return await fn({ request, params: params ?? {} });
    } catch (err) {
      return errorResponse(err, pathOf(request));
    }
  };
}

export async function readJson(request: Request): Promise<unknown> {
  const text = await request.text();
  if (!text.trim()) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw new ApiError(400, "INVALID_JSON", "Request body must be valid JSON.");
  }
}

export function created(body: unknown, location: string) {
  return Response.json(body, {
    status: 201,
    headers: { Location: location },
  });
}

export function parseId(raw: string | undefined, label = "id") {
  const id = Number(raw);
  if (!Number.isInteger(id) || id < 1) {
    throw new ApiError(400, "VALIDATION_ERROR", `${label} must be a positive integer.`);
  }
  return id;
}
