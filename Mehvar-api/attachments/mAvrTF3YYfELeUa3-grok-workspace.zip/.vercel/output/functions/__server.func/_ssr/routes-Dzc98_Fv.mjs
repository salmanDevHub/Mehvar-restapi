import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { d as listProducts, l as listCategories } from "./api-CPtHT2Bv.mjs";
import { d as Layers, f as KeyRound, i as SlidersHorizontal, o as ShieldCheck, p as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-DVlEzcO7.mjs";
import { n as ProductGridSkeleton, t as ProductGrid } from "./product-grid-CoswCJqx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dzc98_Fv.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const featured = useQuery({
		queryKey: ["products", "featured"],
		queryFn: () => listProducts({
			featured: true,
			limit: 6
		})
	});
	const categories = useQuery({
		queryKey: ["categories"],
		queryFn: listCategories
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative overflow-hidden border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-end gap-10 px-4 py-14 sm:px-6 lg:grid-cols-12 lg:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.22em] text-muted",
							children: "Marketplace, recalibrated"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 font-display text-[2.7rem] leading-[0.95] tracking-[-0.04em] sm:text-6xl lg:text-[4.4rem]",
							children: "Commerce on its true axis."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg",
							children: "MEHVAR is a full-stack storefront and enterprise REST catalog. Noun-based URIs, honest HTTP status codes, idempotent checkout, and field selection so mobile clients never download a 50-field product they did not ask for."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/products",
									children: ["Shop the catalog ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/docs",
									children: "Open the API console"
								})
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80",
							alt: "Aurora headphones",
							className: "h-52 w-full rounded-xl object-cover sm:h-64"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?auto=format&fit=crop&w=900&q=80",
							alt: "Midnight overcoat",
							className: "mt-8 h-52 w-full rounded-xl object-cover sm:h-64"
						})]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-14 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.22em] text-muted",
					children: "Departments"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl sm:text-4xl",
					children: "Shop by aisle"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/products",
					className: "hidden text-sm text-muted hover:text-ink sm:inline",
					children: "View all"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5",
				children: (categories.data ?? []).map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/products",
					search: { category: cat.slug },
					className: "group relative overflow-hidden rounded-xl bg-bg-2 ring-1 ring-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: cat.image_url,
							alt: "",
							className: "h-40 w-full object-cover opacity-90 transition-transform duration-500 group-hover:scale-105"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "absolute bottom-3 left-3 font-display text-lg text-bg",
							children: cat.name
						})
					]
				}, cat.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-6 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-end justify-between gap-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.22em] text-muted",
					children: "This week"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl sm:text-4xl",
					children: "Featured pieces"
				})] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: featured.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGridSkeleton, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: featured.data?.data ?? [] })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.22em] text-muted",
					children: "Architecture"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 max-w-2xl font-display text-3xl sm:text-4xl",
					children: "Four promises the old backend never kept."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-4 md:grid-cols-2",
					children: [
						{
							icon: Layers,
							title: "Noun-based REST",
							body: "/api/v1/products, not /getProductsList. GET, POST, PUT, DELETE mean what they always should have."
						},
						{
							icon: ShieldCheck,
							title: "Honest errors",
							body: "400 for bad input, 404 for missing resources, 201 for creation. One JSON envelope: error_code, message, timestamp, path."
						},
						{
							icon: KeyRound,
							title: "Idempotent checkout",
							body: "Send Idempotency-Key on POST /orders. Network retries never double-charge a cart or duplicate a deduction."
						},
						{
							icon: SlidersHorizontal,
							title: "Field selection",
							body: "?fields=title,price returns only those keys. Invalid fields are rejected with a clean 400 — never a 500."
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl bg-surface p-6 ring-1 ring-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5 text-accent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-display text-2xl",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: item.body
							})
						]
					}, item.title))
				})
			]
		})
	] });
}
//#endregion
export { Home as component };
