import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { r as formatMoney } from "./utils-8wapS-q9.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { c as getProduct } from "./api-CPtHT2Bv.mjs";
import { c as Plus, l as Minus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route$9, s as useCart } from "./router-CqOS_0lK.mjs";
import { t as Button } from "./button-DVlEzcO7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products._id-BBzLuIt1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { id } = Route$9.useParams();
	const productId = Number(id);
	const [lean, setLean] = (0, import_react.useState)(false);
	const [qty, setQty] = (0, import_react.useState)(1);
	const add = useCart((s) => s.add);
	const query = useQuery({
		queryKey: [
			"product",
			productId,
			lean
		],
		queryFn: () => getProduct(productId, lean ? "title,price" : void 0),
		enabled: Number.isInteger(productId)
	});
	if (!Number.isInteger(productId)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-3xl px-4 py-16",
		children: "Invalid product."
	});
	if (query.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[4/5] animate-pulse rounded-xl bg-bg-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-2/3 animate-pulse rounded bg-bg-2" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-1/3 animate-pulse rounded bg-bg-2" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 w-full animate-pulse rounded bg-bg-2" })
			]
		})]
	});
	if (query.isError || !query.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-xl px-4 py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl",
				children: "This piece is not on the floor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "The API returned 404 with a structured error envelope."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/products",
					children: "Back to catalog"
				})
			})
		]
	});
	const product = query.data;
	const full = !lean && Boolean(product.description);
	function addToCart() {
		if (!product.id || product.price == null || !product.title || !product.image_url) return;
		add({
			productId: product.id,
			title: product.title,
			price: product.price,
			image: product.image_url,
			stock: product.stock ?? 1
		}, qty);
		toast.success("Added to cart");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-6xl gap-10 px-4 py-10 sm:px-6 lg:grid-cols-2 lg:py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [product.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: product.image_url,
			alt: product.title ?? "Product",
			className: "aspect-[4/5] w-full rounded-xl object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex aspect-[4/5] items-center justify-center rounded-xl bg-bg-2 text-sm text-muted",
			children: "Image omitted by field selection"
		}), full && product.gallery && product.gallery.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid grid-cols-3 gap-3",
			children: product.gallery.map((src) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src,
				alt: "",
				className: "aspect-square rounded-lg object-cover"
			}, src))
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.22em] text-muted",
				children: product.brand || product.category || "MEHVAR"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl sm:text-5xl",
				children: product.title ?? "Untitled"
			}),
			product.price != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xl tabular-nums",
				children: [formatMoney(product.price), product.compare_at_price && product.compare_at_price > product.price && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-3 text-base text-faint line-through",
					children: formatMoney(product.compare_at_price)
				})]
			}),
			full && product.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-[15px] leading-relaxed text-muted",
				children: product.description
			}),
			full && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-8 grid grid-cols-2 gap-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-faint",
						children: "SKU"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-mono text-xs",
						children: product.sku
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-faint",
						children: "Stock"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 tabular-nums",
						children: [product.stock, " in warehouse"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-faint",
						children: "Rating"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 tabular-nums",
						children: [
							product.rating,
							" · ",
							product.review_count,
							" reviews"
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-faint",
						children: "Department"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1",
						children: product.category
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex h-11 items-center rounded-full border border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center",
							onClick: () => setQty((q) => Math.max(1, q - 1)),
							"aria-label": "Decrease quantity",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-6 text-center tabular-nums text-sm",
							children: qty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center",
							onClick: () => setQty((q) => q + 1),
							"aria-label": "Increase quantity",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: addToCart,
					disabled: !product.stock,
					children: product.stock === 0 ? "Sold out" : "Add to cart"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 rounded-xl bg-bg-2 p-4 ring-1 ring-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Bandwidth mode"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs leading-relaxed text-muted",
						children: [
							"When on, this page calls",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("code", {
								className: "font-mono",
								children: [
									"GET /api/v1/products/",
									id,
									"?fields=title,price"
								]
							}),
							" and renders only those keys — the over-fetching fix."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setLean((v) => !v),
						className: `relative h-7 w-12 rounded-full transition-colors ${lean ? "bg-accent" : "bg-border-strong"}`,
						"aria-pressed": lean,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-6 rounded-full bg-surface transition-transform ${lean ? "translate-x-5" : "translate-x-0.5"}` })
					})]
				})
			})
		] })]
	});
}
//#endregion
export { ProductPage as component };
