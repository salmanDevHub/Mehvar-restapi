import { m as Outlet, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useMe, c as RedirectToSignIn, d as useCurrentUserState } from "./router-CqOS_0lK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DSKX-UN_.js
var import_jsx_runtime = require_jsx_runtime();
function AdminLayout() {
	const { user, isPending } = useCurrentUserState();
	const me = useMe();
	if (isPending || me.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "px-4 py-16 text-sm text-muted",
		children: "Opening Studio…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (me.data?.role !== "ADMIN") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-4 py-20 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl",
			children: "Studio is locked"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "This account is a customer. The first member to register on a fresh MEHVAR floor becomes admin."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-6xl px-4 py-8 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.22em] text-muted",
				children: "Operations"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-4xl",
				children: "Studio"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin",
						children: "Overview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin/products",
						children: "Products"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin/orders",
						children: "Orders"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		})]
	});
}
function AdminLink({ to, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: "rounded-full border border-border px-3.5 py-2 text-sm text-muted hover:text-ink",
		activeProps: { className: "rounded-full bg-ink px-3.5 py-2 text-sm text-bg" },
		activeOptions: { exact: to === "/admin" },
		children
	});
}
//#endregion
export { AdminLayout as component };
