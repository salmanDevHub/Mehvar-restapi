import { l as getBearerToken } from "./utils-8wapS-q9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-CPtHT2Bv.js
var ApiClientError = class extends Error {
	error_code;
	status;
	path;
	timestamp;
	constructor(body, status, fallbackPath) {
		super(body.message ?? "Request failed");
		this.name = "ApiClientError";
		this.error_code = body.error_code ?? "ERROR";
		this.status = status;
		this.path = body.path ?? fallbackPath;
		this.timestamp = body.timestamp ?? (/* @__PURE__ */ new Date()).toISOString();
	}
};
async function api(path, init = {}) {
	const headers = new Headers(init.headers);
	headers.set("Accept", "application/json");
	if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
	const token = getBearerToken();
	if (token) headers.set("Authorization", `Bearer ${token}`);
	if (init.idempotencyKey) headers.set("Idempotency-Key", init.idempotencyKey);
	const res = await fetch(path, {
		...init,
		headers,
		credentials: "include"
	});
	if (res.status === 204) return void 0;
	const payload = await res.json().catch(() => null);
	if (!res.ok) throw new ApiClientError(payload ?? {}, res.status, path);
	return payload;
}
function listProducts(params = {}) {
	const qs = new URLSearchParams();
	for (const [key, value] of Object.entries(params)) {
		if (value === void 0 || value === null || value === "") continue;
		qs.set(key, String(value));
	}
	return api(`/api/v1/products${qs.toString() ? `?${qs}` : ""}`);
}
function getProduct(id, fields) {
	return api(`/api/v1/products/${id}${fields ? `?fields=${encodeURIComponent(fields)}` : ""}`);
}
function createProduct(body) {
	return api("/api/v1/products", {
		method: "POST",
		body: JSON.stringify(body)
	});
}
function updateProduct(id, body) {
	return api(`/api/v1/products/${id}`, {
		method: "PUT",
		body: JSON.stringify(body)
	});
}
function deleteProduct(id) {
	return api(`/api/v1/products/${id}`, { method: "DELETE" });
}
function listCategories() {
	return api("/api/v1/categories");
}
function listOrders(params = {}) {
	const qs = new URLSearchParams();
	for (const [key, value] of Object.entries(params)) {
		if (value === void 0 || value === "") continue;
		qs.set(key, String(value));
	}
	return api(`/api/v1/orders${qs.toString() ? `?${qs}` : ""}`);
}
function getOrder(id) {
	return api(`/api/v1/orders/${id}`);
}
function createOrder(body, idempotencyKey) {
	return api("/api/v1/orders", {
		method: "POST",
		body: JSON.stringify(body),
		idempotencyKey
	});
}
function updateOrderStatus(id, status) {
	return api(`/api/v1/orders/${id}`, {
		method: "PUT",
		body: JSON.stringify({ status })
	});
}
function getMe() {
	return api("/api/v1/auth/me");
}
function getInventory() {
	return api("/api/v1/inventory");
}
//#endregion
export { getInventory as a, getProduct as c, listProducts as d, updateOrderStatus as f, deleteProduct as i, listCategories as l, createOrder as n, getMe as o, updateProduct as p, createProduct as r, getOrder as s, ApiClientError as t, listOrders as u };
