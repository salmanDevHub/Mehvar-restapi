import { r as formatMoney } from "./utils-8wapS-q9.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-grid-CoswCJqx.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product }) {
	const soldOut = product.stock <= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/products/$id",
		params: { id: String(product.id) },
		className: "group flex flex-col overflow-hidden rounded-xl bg-surface shadow-[0_18px_40px_-28px_rgb(23_20_17_/_0.45)] ring-1 ring-border transition-transform duration-200 hover:-translate-y-0.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[4/5] overflow-hidden bg-bg-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: product.image_url,
					alt: product.title,
					className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
				}),
				soldOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute left-3 top-3 rounded-full bg-ink/85 px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] text-bg",
					children: "Sold out"
				}),
				product.featured && !soldOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute left-3 top-3 rounded-full bg-surface/90 px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] text-ink",
					children: "Featured"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.16em] text-faint",
					children: product.brand || product.category
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-display text-lg leading-snug tracking-[-0.03em]",
					children: product.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex items-baseline gap-2 pt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-sm font-medium",
						children: formatMoney(product.price)
					}), product.compare_at_price && product.compare_at_price > product.price && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-faint line-through tabular-nums",
						children: formatMoney(product.compare_at_price)
					})]
				})
			]
		})]
	});
}
function ProductGrid({ products }) {
	if (products.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-dashed border-border-strong bg-surface px-6 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl",
			children: "Nothing in this aisle"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Try another category, or clear the search."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
		children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
	});
}
function ProductGridSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
		children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-xl bg-surface ring-1 ring-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[4/5] animate-pulse bg-bg-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-16 animate-pulse rounded bg-bg-2" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-3/4 animate-pulse rounded bg-bg-2" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-20 animate-pulse rounded bg-bg-2" })
				]
			})]
		}, i))
	});
}
//#endregion
export { ProductGridSkeleton as n, ProductGrid as t };
