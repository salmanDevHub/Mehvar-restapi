import { n as formatDate, r as formatMoney } from "./utils-8wapS-q9.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { f as updateOrderStatus, t as ApiClientError, u as listOrders } from "./api-CPtHT2Bv.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.orders-DOvJyQLp.js
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"pending",
	"paid",
	"packed",
	"shipped",
	"delivered",
	"cancelled"
];
function AdminOrders() {
	const qc = useQueryClient();
	const orders = useQuery({
		queryKey: ["admin", "orders-all"],
		queryFn: () => listOrders({ limit: 50 })
	});
	const mutate = useMutation({
		mutationFn: ({ id, status }) => updateOrderStatus(id, status),
		onSuccess: () => {
			toast.success("Order updated");
			qc.invalidateQueries({ queryKey: ["admin"] });
		},
		onError: (err) => toast.error(err instanceof ApiClientError ? err.message : "Update failed")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: "Fulfillment"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: [
				"PUT /api/v1/orders/",
				"{id}",
				" is idempotent — repeating the same status is a no-op."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 overflow-x-auto rounded-xl bg-surface ring-1 ring-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[640px] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b border-border text-xs uppercase tracking-[0.12em] text-faint",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "ID"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "When"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Ship to"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Total"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Status"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [(orders.data?.data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 5,
					className: "px-4 py-10 text-center text-muted",
					children: "No orders yet."
				}) }), (orders.data?.data ?? []).map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3 tabular-nums",
							children: ["#", order.id]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 text-muted",
							children: formatDate(order.created_at)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3",
							children: [order.shipping_name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-faint",
								children: order.shipping_city
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 tabular-nums",
							children: formatMoney(order.total)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: order.status,
								onChange: (e) => mutate.mutate({
									id: order.id,
									status: e.target.value
								}),
								className: "h-9 rounded-md border border-border bg-bg px-2 text-xs uppercase tracking-[0.12em]",
								children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: s,
									children: s
								}, s))
							})
						})
					]
				}, order.id))] })]
			})
		})
	] });
}
//#endregion
export { AdminOrders as component };
