import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { d as listProducts, l as listCategories } from "./api-CPtHT2Bv.mjs";
import { i as Route$15 } from "./router-CqOS_0lK.mjs";
import { n as ProductGridSkeleton, t as ProductGrid } from "./product-grid-CoswCJqx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products-BHxD-1d4.js
var import_jsx_runtime = require_jsx_runtime();
function ProductsPage() {
	const search = Route$15.useSearch();
	const page = search.page ?? 1;
	const cats = useQuery({
		queryKey: ["categories"],
		queryFn: listCategories
	});
	const catalog = useQuery({
		queryKey: [
			"products",
			search.category,
			search.search,
			page
		],
		queryFn: () => listProducts({
			category: search.category,
			search: search.search,
			page,
			limit: 9
		})
	});
	const totalPages = catalog.data?.meta.total_pages ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-6xl px-4 py-10 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.22em] text-muted",
				children: "Catalog"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl sm:text-5xl",
				children: "The floor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 max-w-xl text-sm text-muted",
				children: [
					"Filter by department, search by title, and page through a paginated REST collection —",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
						className: "font-mono text-xs",
						children: "GET /api/v1/products"
					}),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					to: "/products",
					search: {
						search: search.search,
						page: 1
					},
					active: !search.category,
					children: "All"
				}), (cats.data ?? []).map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					to: "/products",
					search: {
						category: cat.slug,
						search: search.search,
						page: 1
					},
					active: search.category === cat.slug,
					children: cat.name
				}, cat.id))]
			}),
			search.search && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-5 text-sm text-muted",
				children: ["Results for ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-ink",
					children: [
						"“",
						search.search,
						"”"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: catalog.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGridSkeleton, {}) : catalog.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-xl border border-danger/30 bg-surface px-4 py-8 text-sm text-danger",
					children: "The catalog could not be loaded. Try again in a moment."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: catalog.data?.data ?? [] })
			}),
			totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 flex items-center justify-center gap-2",
				children: Array.from({ length: totalPages }).map((_, i) => {
					const n = i + 1;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/products",
						search: {
							...search,
							page: n
						},
						className: `inline-flex size-10 items-center justify-center rounded-full text-sm tabular-nums ${n === page ? "bg-ink text-bg" : "border border-border hover:bg-bg-2"}`,
						children: n
					}, n);
				})
			})
		]
	});
}
function FilterChip({ children, active, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		...props,
		className: `rounded-full px-3.5 py-2 text-sm ${active ? "bg-ink text-bg" : "border border-border bg-surface text-muted hover:text-ink"}`,
		children
	});
}
//#endregion
export { ProductsPage as component };
