import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { r as formatMoney } from "./utils-8wapS-q9.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { d as listProducts, i as deleteProduct, l as listCategories, p as updateProduct, r as createProduct, t as ApiClientError } from "./api-CPtHT2Bv.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-DVlEzcO7.mjs";
import { t as Input } from "./input-CK4ZlBR2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.products-C694HwEl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminProducts() {
	const qc = useQueryClient();
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [creating, setCreating] = (0, import_react.useState)(false);
	const products = useQuery({
		queryKey: ["admin", "products-all"],
		queryFn: () => listProducts({ limit: 50 })
	});
	const categories = useQuery({
		queryKey: ["categories"],
		queryFn: listCategories
	});
	const remove = useMutation({
		mutationFn: (id) => deleteProduct(id),
		onSuccess: () => {
			toast.success("Product removed");
			qc.invalidateQueries({ queryKey: ["admin"] });
			qc.invalidateQueries({ queryKey: ["products"] });
		},
		onError: (err) => toast.error(err instanceof ApiClientError ? err.message : "Could not delete")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Merchandise"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				onClick: () => {
					setCreating(true);
					setEditing(null);
				},
				children: "New product"
			})]
		}),
		(creating || editing) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductForm, {
			initial: editing,
			categories: categories.data ?? [],
			onCancel: () => {
				setCreating(false);
				setEditing(null);
			},
			onSaved: () => {
				setCreating(false);
				setEditing(null);
				qc.invalidateQueries({ queryKey: ["admin"] });
				qc.invalidateQueries({ queryKey: ["products"] });
			}
		}, editing?.id ?? "new"),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 overflow-x-auto rounded-xl bg-surface ring-1 ring-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[640px] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b border-border text-xs uppercase tracking-[0.12em] text-faint",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Title"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Price"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Stock"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Dept"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3 font-medium" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: (products.data?.data ?? []).map((row) => {
					const p = row;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: p.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: formatMoney(p.price)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: p.stock
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted",
								children: p.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mr-3 text-xs uppercase tracking-[0.12em] text-muted hover:text-ink",
									onClick: () => {
										setEditing(p);
										setCreating(false);
									},
									children: "Edit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-xs uppercase tracking-[0.12em] text-danger",
									onClick: () => remove.mutate(p.id),
									children: "Delete"
								})]
							})
						]
					}, p.id);
				}) })]
			})
		})
	] });
}
function ProductForm({ initial, categories, onCancel, onSaved }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onSubmit(e) {
		e.preventDefault();
		const form = new FormData(e.currentTarget);
		const body = {
			title: String(form.get("title") ?? ""),
			description: String(form.get("description") ?? ""),
			price: Number(form.get("price")),
			compare_at_price: form.get("compare_at_price") ? Number(form.get("compare_at_price")) : null,
			stock: Number(form.get("stock")),
			category_id: Number(form.get("category_id")),
			image_url: String(form.get("image_url") ?? ""),
			brand: String(form.get("brand") ?? ""),
			sku: String(form.get("sku") ?? "") || void 0,
			featured: form.get("featured") === "on"
		};
		setBusy(true);
		try {
			if (initial) await updateProduct(initial.id, body);
			else await createProduct(body);
			toast.success(initial ? "Product updated" : "Product created");
			onSaved();
		} catch (err) {
			toast.error(err instanceof ApiClientError ? err.message : "Save failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "mt-6 grid gap-3 rounded-xl bg-surface p-5 ring-1 ring-border sm:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Title",
				name: "title",
				defaultValue: initial?.title,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Brand",
				name: "brand",
				defaultValue: initial?.brand
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "sm:col-span-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1.5 block text-muted",
					children: "Description"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					name: "description",
					required: true,
					minLength: 12,
					defaultValue: initial?.description,
					rows: 3,
					className: "w-full rounded-md border border-border bg-bg px-3.5 py-2.5 text-sm outline-none focus:border-accent"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Price",
				name: "price",
				type: "number",
				step: "0.01",
				defaultValue: initial?.price,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Compare-at price",
				name: "compare_at_price",
				type: "number",
				step: "0.01",
				defaultValue: initial?.compare_at_price ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Stock",
				name: "stock",
				type: "number",
				defaultValue: initial?.stock ?? 0,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1.5 block text-muted",
					children: "Category"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					name: "category_id",
					defaultValue: initial?.category_id,
					className: "h-11 w-full rounded-md border border-border bg-bg px-3 text-sm",
					required: true,
					children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: c.id,
						children: c.name
					}, c.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Image URL",
				name: "image_url",
				defaultValue: initial?.image_url,
				required: true,
				className: "sm:col-span-2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "SKU (optional)",
				name: "sku",
				defaultValue: initial?.sku
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					name: "featured",
					defaultChecked: initial?.featured
				}), "Featured"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 sm:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					children: busy ? "Saving…" : initial ? "Save (idempotent PUT)" : "Create"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					onClick: onCancel,
					children: "Cancel"
				})]
			})
		]
	});
}
function Field(props) {
	const { label, className, ...rest } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: `text-sm ${className ?? ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...rest })]
	});
}
//#endregion
export { AdminProducts as component };
