import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { r as formatMoney } from "./utils-8wapS-q9.mjs";
import { b as useNavigate, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as createOrder, t as ApiClientError } from "./api-CPtHT2Bv.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as RedirectToSignIn, d as useCurrentUserState, o as cartTotal, s as useCart } from "./router-CqOS_0lK.mjs";
import { t as Button } from "./button-DVlEzcO7.mjs";
import { t as Input } from "./input-CK4ZlBR2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-F58BzfYf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CheckoutPage() {
	const { user, isPending } = useCurrentUserState();
	const items = useCart((s) => s.items);
	const clear = useCart((s) => s.clear);
	const navigate = useNavigate();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const keyRef = (0, import_react.useRef)(crypto.randomUUID());
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-xl px-4 py-20 text-sm text-muted",
		children: "Checking your session…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-xl px-4 py-20 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl",
			children: "Nothing to settle"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/products",
				children: "Return to catalog"
			})
		})]
	});
	async function onSubmit(e) {
		e.preventDefault();
		const form = new FormData(e.currentTarget);
		setBusy(true);
		try {
			const order = await createOrder({
				shipping_name: String(form.get("shipping_name") ?? ""),
				shipping_address: String(form.get("shipping_address") ?? ""),
				shipping_city: String(form.get("shipping_city") ?? ""),
				shipping_phone: String(form.get("shipping_phone") ?? ""),
				notes: String(form.get("notes") ?? ""),
				items: items.map((item) => ({
					product_id: item.productId,
					quantity: item.qty
				}))
			}, keyRef.current);
			clear();
			toast.success(`Order #${order.id} placed`);
			navigate({
				to: "/orders/$id",
				params: { id: String(order.id) }
			});
		} catch (err) {
			const message = err instanceof ApiClientError ? err.message : "Checkout failed.";
			toast.error(message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid w-full max-w-5xl gap-10 px-4 py-10 sm:px-6 lg:grid-cols-[1fr_300px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.22em] text-muted",
				children: "Checkout"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: "Dispatch details"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 max-w-lg text-sm text-muted",
				children: [
					"This form posts to ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
						className: "font-mono text-xs",
						children: "POST /api/v1/orders"
					}),
					" with a stable",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
						className: "font-mono text-xs",
						children: "Idempotency-Key"
					}),
					". Retrying the same submit will not create a second order."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-8 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Full name",
						name: "shipping_name",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Street address",
						name: "shipping_address",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "City",
						name: "shipping_city",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						name: "shipping_phone",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1.5 block text-muted",
							children: "Notes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							name: "notes",
							rows: 3,
							className: "w-full rounded-md border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:border-accent"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "lg",
						disabled: busy,
						children: busy ? "Placing order…" : "Place order"
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "h-fit rounded-xl bg-surface p-5 ring-1 ring-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Summary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3 text-sm",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [
								item.title,
								" × ",
								item.qty
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: formatMoney(item.price * item.qty)
						})]
					}, item.productId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex justify-between border-t border-border pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium tabular-nums",
						children: formatMoney(cartTotal(items))
					})]
				})
			]
		})]
	});
}
function Field({ label, name, required }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			name,
			required
		})]
	});
}
//#endregion
export { CheckoutPage as component };
