import { n as formatDate, r as formatMoney } from "./utils-8wapS-q9.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { s as getOrder } from "./api-CPtHT2Bv.mjs";
import { c as RedirectToSignIn, d as useCurrentUserState, r as Route$10 } from "./router-CqOS_0lK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders._id-Df3YTHsF.js
var import_jsx_runtime = require_jsx_runtime();
function OrderDetailPage() {
	const { id } = Route$10.useParams();
	const { user, isPending } = useCurrentUserState();
	const query = useQuery({
		queryKey: ["order", id],
		queryFn: () => getOrder(Number(id)),
		enabled: !isPending && Boolean(user)
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "px-4 py-16 text-sm text-muted",
		children: "Loading…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (query.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-2xl px-4 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-xl bg-bg-2" })
	});
	if (query.isError || !query.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-xl px-4 py-20 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl",
			children: "Order not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/orders",
			className: "mt-4 inline-block text-sm text-muted hover:text-ink",
			children: "Back to orders"
		})]
	});
	const order = query.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-2xl px-4 py-10 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] uppercase tracking-[0.22em] text-muted",
				children: ["Order #", order.id]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: formatMoney(order.total)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [
					formatDate(order.created_at),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "uppercase tracking-[0.12em]",
						children: order.status
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 divide-y divide-border rounded-xl bg-surface ring-1 ring-border",
				children: order.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-4 px-5 py-4 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						item.title,
						" × ",
						item.quantity
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatMoney(item.line_total)
					})]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-ink",
					children: "Ship to"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1",
					children: [
						order.shipping_name,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						order.shipping_address,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						order.shipping_city
					]
				})]
			})
		]
	});
}
//#endregion
export { OrderDetailPage as component };
