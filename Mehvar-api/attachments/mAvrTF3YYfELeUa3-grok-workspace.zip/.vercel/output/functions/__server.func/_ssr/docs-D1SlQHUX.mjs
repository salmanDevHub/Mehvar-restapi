import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { l as getBearerToken } from "./utils-8wapS-q9.mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-DVlEzcO7.mjs";
import { t as Input } from "./input-CK4ZlBR2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/docs-D1SlQHUX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EXAMPLES = [
	{
		name: "List products",
		method: "GET",
		path: "/api/v1/products?limit=5"
	},
	{
		name: "Filter + paginate",
		method: "GET",
		path: "/api/v1/products?category=electronics&page=1&limit=5"
	},
	{
		name: "Search",
		method: "GET",
		path: "/api/v1/products?search=headphones"
	},
	{
		name: "Field selection",
		method: "GET",
		path: "/api/v1/products/1?fields=title,price"
	},
	{
		name: "Invalid fields → 400",
		method: "GET",
		path: "/api/v1/products/1?fields=title,vendor_secrets"
	},
	{
		name: "Missing product → 404",
		method: "GET",
		path: "/api/v1/products/99999"
	},
	{
		name: "Current session",
		method: "GET",
		path: "/api/v1/auth/me"
	}
];
function DocsPage() {
	const [method, setMethod] = (0, import_react.useState)("GET");
	const [path, setPath] = (0, import_react.useState)("/api/v1/products/1?fields=title,price");
	const [body, setBody] = (0, import_react.useState)("{\n  \"status\": \"paid\"\n}");
	const [idem, setIdem] = (0, import_react.useState)("");
	const [result, setResult] = (0, import_react.useState)("Send a request to see the live envelope.");
	const [status, setStatus] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function send() {
		setBusy(true);
		try {
			const headers = { Accept: "application/json" };
			const token = getBearerToken();
			if (token) headers.Authorization = `Bearer ${token}`;
			if (idem.trim()) headers["Idempotency-Key"] = idem.trim();
			const init = {
				method,
				headers,
				credentials: "include"
			};
			if (method !== "GET" && method !== "DELETE") {
				headers["Content-Type"] = "application/json";
				init.body = body;
			}
			const res = await fetch(path, init);
			setStatus(res.status);
			if (res.status === 204) setResult("(no content)");
			else {
				const json = await res.json().catch(() => null);
				setResult(JSON.stringify(json, null, 2));
			}
		} catch (err) {
			setStatus(null);
			setResult(err instanceof Error ? err.message : "Request failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-6xl px-4 py-10 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.22em] text-muted",
				children: "Reference"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl sm:text-5xl",
				children: "REST console"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
				children: [
					"MEHVAR exposes a versioned HTTP API at ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
						className: "font-mono text-xs",
						children: "/api/v1"
					}),
					". This console talks to the same handlers the storefront uses — no mocks."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 ring-1 ring-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Resources"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-1 font-mono text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "GET /api/v1/products" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"GET /api/v1/products/",
								"{id}",
								"?fields=title,price"
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "POST /api/v1/products" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["PUT /api/v1/products/", "{id}"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["DELETE /api/v1/products/", "{id}"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "GET|POST /api/v1/categories" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["PUT|DELETE /api/v1/categories/", "{id}"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "GET|POST /api/v1/orders · Idempotency-Key" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["GET|PUT /api/v1/orders/", "{id}"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "GET /api/v1/inventory" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "GET /api/v1/auth/me" })
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 ring-1 ring-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Error envelope"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-3 overflow-x-auto font-mono text-xs leading-relaxed text-muted",
						children: `{
  "error_code": "PRODUCT_NOT_FOUND",
  "message": "Product with ID 123 was not found.",
  "timestamp": "2026-09-22T21:30:00Z",
  "path": "/api/v1/products/123"
}`
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-wrap gap-2",
				children: EXAMPLES.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setMethod(ex.method);
						setPath(ex.path);
					},
					className: "rounded-full border border-border bg-surface px-3 py-1.5 text-xs hover:border-border-strong",
					children: ex.name
				}, ex.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 lg:grid-cols-[1fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: method,
								onChange: (e) => setMethod(e.target.value),
								className: "h-11 rounded-md border border-border bg-surface px-2 text-sm",
								children: [
									"GET",
									"POST",
									"PUT",
									"DELETE"
								].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: m }, m))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: path,
								onChange: (e) => setPath(e.target.value),
								className: "font-mono text-xs"
							})]
						}),
						(method === "POST" || method === "PUT") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: body,
							onChange: (e) => setBody(e.target.value),
							rows: 8,
							className: "w-full rounded-md border border-border bg-surface p-3 font-mono text-xs outline-none focus:border-accent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: idem,
							onChange: (e) => setIdem(e.target.value),
							placeholder: "Idempotency-Key (optional)",
							className: "font-mono text-xs"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void send(),
							disabled: busy,
							children: busy ? "Sending…" : "Send request"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-ink p-4 text-bg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.16em] text-bg/60",
						children: status == null ? "idle" : `HTTP ${status}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-3 max-h-[420px] overflow-auto font-mono text-xs leading-relaxed text-bg/90",
						children: result
					})]
				})]
			})
		]
	});
}
//#endregion
export { DocsPage as component };
