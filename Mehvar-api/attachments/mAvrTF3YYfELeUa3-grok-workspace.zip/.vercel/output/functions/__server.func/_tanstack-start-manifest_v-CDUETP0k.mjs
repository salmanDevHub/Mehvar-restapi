//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CDUETP0k.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/cart",
			"/checkout",
			"/docs",
			"/login",
			"/orders",
			"/products",
			"/register",
			"/api/auth/$",
			"/api/v1/categories",
			"/api/v1/inventory",
			"/api/v1/orders",
			"/api/v1/products",
			"/api/v1/auth/me"
		],
		preloads: [
			"/assets/index-CPcVOqZS.js",
			"/assets/jsx-runtime-Cltr0gcK.js",
			"/assets/link-CY_3yKXA.js",
			"/assets/matchContext-D7fiU5TJ.js",
			"/assets/preload-helper-CAef6lJy.js",
			"/assets/useNavigate-BsnLzbYR.js",
			"/assets/useQuery-CI2Ma1OZ.js",
			"/assets/utils-D4saOd5z.js",
			"/assets/client-C2UzX-Xv.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CPcVOqZS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CKOVAhg5.js",
			"/assets/button-BrD8VR5P.js",
			"/assets/product-grid-C5hqp0Td.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: [
			"/admin/orders",
			"/admin/products",
			"/admin/"
		],
		preloads: ["/assets/admin-D7t3faEa.js"]
	},
	"/cart": {
		filePath: "/workspace/src/routes/cart.tsx",
		children: void 0,
		preloads: [
			"/assets/cart-DayAqz0Y.js",
			"/assets/plus-DD1_6IWx.js",
			"/assets/button-BrD8VR5P.js"
		]
	},
	"/checkout": {
		filePath: "/workspace/src/routes/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-B5aFd2gW.js",
			"/assets/button-BrD8VR5P.js",
			"/assets/input-7Ac62V2Q.js"
		]
	},
	"/docs": {
		filePath: "/workspace/src/routes/docs.tsx",
		children: void 0,
		preloads: [
			"/assets/docs-D_7hRbv0.js",
			"/assets/button-BrD8VR5P.js",
			"/assets/input-7Ac62V2Q.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-BH8pgAov.js",
			"/assets/providers-R25ah5Ot.js",
			"/assets/button-BrD8VR5P.js",
			"/assets/input-7Ac62V2Q.js"
		]
	},
	"/orders": {
		filePath: "/workspace/src/routes/orders.tsx",
		children: ["/orders/$id"],
		preloads: ["/assets/orders-CG1_qKU9.js"]
	},
	"/products": {
		filePath: "/workspace/src/routes/products.tsx",
		children: ["/products/$id"],
		preloads: ["/assets/products-B_EhoCNw.js", "/assets/product-grid-C5hqp0Td.js"]
	},
	"/register": {
		filePath: "/workspace/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-bVRApiMw.js",
			"/assets/providers-R25ah5Ot.js",
			"/assets/button-BrD8VR5P.js",
			"/assets/input-7Ac62V2Q.js"
		]
	},
	"/admin/orders": {
		filePath: "/workspace/src/routes/admin.orders.tsx",
		children: void 0,
		preloads: ["/assets/admin.orders-D1HfZKUn.js", "/assets/useMutation-BkpzB6l3.js"]
	},
	"/admin/products": {
		filePath: "/workspace/src/routes/admin.products.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.products-DmxRYX5a.js",
			"/assets/useMutation-BkpzB6l3.js",
			"/assets/button-BrD8VR5P.js",
			"/assets/input-7Ac62V2Q.js"
		]
	},
	"/orders/$id": {
		filePath: "/workspace/src/routes/orders.$id.tsx",
		children: void 0,
		preloads: ["/assets/orders._id-CCl_Xlrf.js"]
	},
	"/products/$id": {
		filePath: "/workspace/src/routes/products.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products._id-DN0X65KP.js",
			"/assets/plus-DD1_6IWx.js",
			"/assets/button-BrD8VR5P.js"
		]
	},
	"/admin/": {
		filePath: "/workspace/src/routes/admin.index.tsx",
		children: void 0,
		preloads: ["/assets/admin.index-CIiV9Pgn.js"]
	}
} });
//#endregion
export { tsrStartManifest };
