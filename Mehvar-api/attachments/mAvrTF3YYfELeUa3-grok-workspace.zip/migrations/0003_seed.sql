-- Catalog seed. Idempotent so re-runs in preview don't duplicate.

insert into categories (id, slug, name, description, image_url)
values
  (1, 'electronics', 'Electronics', 'Sound, capture and everyday tech with a quieter finish.', 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1400&q=80'),
  (2, 'fashion', 'Fashion', 'Cut, cloth and silhouette from ateliers across the region.', 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1400&q=80'),
  (3, 'home', 'Home & Living', 'Objects for the table, the bed, and the late evening.', 'https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=1400&q=80'),
  (4, 'beauty', 'Beauty', 'Attars, creams and serums with a restrained formula.', 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1400&q=80'),
  (5, 'sport', 'Sport & Outdoor', 'Kit that earns its weight on the trail and the mat.', 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=1400&q=80')
on conflict (id) do nothing;

select setval('categories_id_seq', (select max(id) from categories));

insert into products (
  id, title, slug, description, price, compare_at_price, stock, category_id,
  image_url, gallery, brand, sku, rating, review_count, featured
) values
  (
    1,
    'Aurora Wireless Headphones',
    'aurora-wireless-headphones',
    'Closed-back wireless cans with a warm, studio-leaning signature. Memory-foam pads, 38-hour battery, and a folded travel hinge that actually survives a week in a bag. Tuned for long listening rather than showroom bass.',
    189.00, 249.00, 42, 1,
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1484704849700-f032d28bc05f?auto=format&fit=crop&w=1400&q=80","https://images.unsplash.com/photo-1546435770-a3e7468b6251?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Lumen', 'LMN-HD-AURORA', 4.80, 312, true
  ),
  (
    2,
    'Lumen Field Watch',
    'lumen-field-watch',
    'A titanium-cased field watch with a sapphire crystal and a 10-day power reserve in hybrid mode. Always-on display, offline maps, and a strap that does not pretend to be leather.',
    329.00, 389.00, 28, 1,
    'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Lumen', 'LMN-WT-FIELD', 4.70, 198, true
  ),
  (
    3,
    'Nova 4K Action Camera',
    'nova-4k-action-camera',
    'Stabilised 4K60 in a body that fits a jacket pocket. Dual microphones, a daylight-balanced colour profile, and a cage-free mount system for bars, packs and dashboards.',
    279.00, null, 35, 1,
    'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1526170375885-4d8ecf92b96b?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Nova', 'NVA-CAM-4K', 4.60, 154, false
  ),
  (
    4,
    'Orbit Portable Speaker',
    'orbit-portable-speaker',
    'A cylindrical aluminium speaker with a surprisingly wide stereo image. IP67, 18-hour playback, and a carry loop that does not look like an afterthought.',
    129.00, 159.00, 64, 1,
    'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Orbit', 'ORB-SP-01', 4.50, 421, false
  ),
  (
    5,
    'Karachi Linen Shirt',
    'karachi-linen-shirt',
    'Stone-washed European linen, cut in a relaxed camp collar. Breathable enough for a Karachi afternoon, structured enough for a Friday table. Mother-of-pearl buttons, single chest pocket.',
    89.00, 110.00, 51, 2,
    'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1603252109360-909baaf261c7?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Atelier Indus', 'IND-SH-LINEN', 4.70, 88, true
  ),
  (
    6,
    'Midnight Wool Overcoat',
    'midnight-wool-overcoat',
    'Italian wool-cashmere, charcoal midnight, with a concealed placket and a half-belt back. Weight that reads as architecture rather than bulk. Fully lined, interior ticket pocket.',
    420.00, 490.00, 16, 2,
    'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1544923246-77307dd628cb?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Atelier Indus', 'IND-CT-MIDNIGHT', 4.90, 47, true
  ),
  (
    7,
    'Atlas Court Sneakers',
    'atlas-court-sneakers',
    'Full-grain leather court shoe on a gum sole. Unlined for a fast break-in, with a removable insole and a shape that sits under tailored trousers as easily as denim.',
    165.00, null, 40, 2,
    'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Atlas', 'ATL-SN-COURT', 4.60, 203, false
  ),
  (
    8,
    'Indus Silk Scarf',
    'indus-silk-scarf',
    'Hand-rolled 90cm silk twill, printed from a river-map of the Indus. Lightweight enough for a jacket lapel, substantial enough as a headscarf. Colourway: silt and ink.',
    75.00, 95.00, 33, 2,
    'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Atelier Indus', 'IND-SC-SILK', 4.80, 61, false
  ),
  (
    9,
    'Marble Pour-Over Set',
    'marble-pour-over-set',
    'A two-piece pour-over in honed white marble and borosilicate glass. The dripper seats a standard 02 filter. Includes a walnut stand. Built for a slow morning, not a gadget drawer.',
    94.00, null, 22, 3,
    'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Hearth', 'HRT-CO-MARBLE', 4.70, 79, true
  ),
  (
    10,
    'Teak Serving Board',
    'teak-serving-board',
    'Reclaimed teak with a juice groove and a quiet oil finish. 48cm, with a leather hanging loop. Every board is slightly different — that is the point.',
    68.00, 82.00, 29, 3,
    'https://images.unsplash.com/photo-1556911220-e15b21be1d22?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1466637574441-749b8f2c5fd0?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Hearth', 'HRT-BR-TEAK', 4.50, 112, false
  ),
  (
    11,
    'Stonewashed Linen Duvet',
    'stonewashed-linen-duvet',
    'Stonewashed Belgian linen duvet cover, 200-thread equivalent in hand if not in number. Button closure, interior ties, and a colour that hides the morning.',
    210.00, 250.00, 18, 3,
    'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Hearth', 'HRT-BD-LINEN', 4.80, 56, false
  ),
  (
    12,
    'Brass Arc Lamp',
    'brass-arc-lamp',
    'A compact arc lamp in unlacquered brass that will take on a living patina. E27 socket, linen shade, weighted marble base. Dimmer-compatible.',
    245.00, null, 14, 3,
    'https://images.unsplash.com/photo-1507473880760-e62ecd43edba?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Hearth', 'HRT-LP-ARC', 4.60, 38, true
  ),
  (
    13,
    'Sandalwood Attar',
    'sandalwood-attar',
    'Traditional sandalwood attar, distilled in Kannauj and bottled at 12ml. No alcohol, no top-note theatre — a dry, close-to-skin wood that lasts through the day.',
    58.00, 72.00, 47, 4,
    'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Noor', 'NOR-AT-SANDAL', 4.90, 267, true
  ),
  (
    14,
    'Mineral Day Cream',
    'mineral-day-cream',
    'A mineral SPF 30 day cream with zinc oxide and squalane. No white cast on deeper skin, no fragrance. 50ml airless pump.',
    42.00, null, 80, 4,
    'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1571781926291-c477ebcc971f?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Noor', 'NOR-CR-DAY', 4.40, 190, false
  ),
  (
    15,
    'Rosehip Night Serum',
    'rosehip-night-serum',
    'Cold-pressed rosehip with bakuchiol. A night serum for texture, not a miracle. 30ml dropper, dark glass, no essential oils.',
    36.00, 44.00, 71, 4,
    'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1611930022073-b7a4ba5aa6b1?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Noor', 'NOR-SR-ROSE', 4.60, 143, false
  ),
  (
    16,
    'Trail Running Pack 12L',
    'trail-running-pack-12l',
    'A 12-litre vest pack with bounce-free flasks and a rear shove-it. Recycled nylon, reflective seam tape, and a cut that does not chew the shoulders after kilometre twenty.',
    118.00, 140.00, 24, 5,
    'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1622260614153-03223fb72052?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Range', 'RNG-PK-12', 4.70, 97, true
  ),
  (
    17,
    'Graphite Yoga Mat',
    'graphite-yoga-mat',
    'Natural rubber mat, 4.5mm, closed-cell top that does not turn into a slide after sun salutations. Graphite colourway. Alignment marks are faint on purpose.',
    72.00, null, 39, 5,
    'https://images.unsplash.com/photo-1601925260368-ae2f4cbf8a19?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Range', 'RNG-YM-GRAPHITE', 4.50, 128, false
  ),
  (
    18,
    'Carbon Insulated Bottle',
    'carbon-insulated-bottle',
    'Double-wall stainless, 750ml, keeps ice through a Karachi August. Narrow mouth, no-sweat exterior, and a cap you can actually open with one hand.',
    38.00, 48.00, 90, 5,
    'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=1400&q=80',
    '["https://images.unsplash.com/photo-1523362628745-0c100150b504?auto=format&fit=crop&w=1400&q=80"]'::jsonb,
    'Range', 'RNG-BT-750', 4.40, 310, false
  )
on conflict (id) do nothing;

select setval('products_id_seq', (select max(id) from products));
