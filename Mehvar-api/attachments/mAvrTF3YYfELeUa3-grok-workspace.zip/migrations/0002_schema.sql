-- MEHVAR commerce schema
-- Catalog is world-readable; orders and profiles are per-user.

create table if not exists profiles (
  user_id    text primary key,
  role       text not null default 'CUSTOMER' check (role in ('CUSTOMER', 'ADMIN')),
  full_name  text,
  created_at timestamptz not null default now()
);

create table if not exists categories (
  id          serial primary key,
  slug        text not null unique,
  name        text not null,
  description text not null default '',
  image_url   text not null default '',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists products (
  id               serial primary key,
  title            text not null,
  slug             text not null unique,
  description      text not null,
  price            numeric(12,2) not null check (price >= 0),
  compare_at_price numeric(12,2) check (compare_at_price is null or compare_at_price >= 0),
  stock            integer not null default 0 check (stock >= 0),
  category_id      integer not null references categories(id) on delete restrict,
  image_url        text not null,
  gallery          jsonb not null default '[]'::jsonb,
  brand            text not null default '',
  sku              text not null unique,
  rating           numeric(3,2) not null default 4.60,
  review_count     integer not null default 0,
  featured         boolean not null default false,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create index if not exists products_category_id_idx on products (category_id);
create index if not exists products_featured_idx on products (featured);
create index if not exists products_title_idx on products (lower(title));

create table if not exists orders (
  id               serial primary key,
  user_id          text not null,
  status           text not null default 'pending'
                   check (status in ('pending', 'paid', 'packed', 'shipped', 'delivered', 'cancelled')),
  total            numeric(12,2) not null check (total >= 0),
  shipping_name    text not null,
  shipping_address text not null,
  shipping_city    text not null,
  shipping_phone   text not null default '',
  notes            text not null default '',
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create index if not exists orders_user_id_idx on orders (user_id);
create index if not exists orders_status_idx on orders (status);

create table if not exists order_items (
  id          serial primary key,
  order_id    integer not null references orders(id) on delete cascade,
  product_id  integer not null references products(id),
  title       text not null,
  unit_price  numeric(12,2) not null,
  quantity    integer not null check (quantity > 0),
  line_total  numeric(12,2) not null
);

create index if not exists order_items_order_id_idx on order_items (order_id);

-- Idempotency ledger for order creation (and reusable for other mutations).
create table if not exists idempotency_keys (
  key              text primary key,
  user_id          text not null,
  request_hash     text not null,
  response_status  integer not null,
  response_body    jsonb not null,
  created_at       timestamptz not null default now()
);

create index if not exists idempotency_keys_user_id_idx on idempotency_keys (user_id);
