# MEHVAR HTTP API

Versioned at `/api/v1`. JSON in, JSON out. Errors always use:

```json
{
  "error_code": "PRODUCT_NOT_FOUND",
  "message": "Product with ID 123 was not found.",
  "timestamp": "2026-09-22T21:30:00.000Z",
  "path": "/api/v1/products/123"
}
```

## Status map

| Code | When |
| --- | --- |
| 200 | Successful read or idempotent PUT |
| 201 | Resource created (`Location` header set) |
| 204 | Successful DELETE |
| 400 | Validation, invalid `fields`, invalid pagination |
| 401 | Missing or expired session |
| 403 | Authenticated but not admin |
| 404 | Unknown product, category, or order |
| 409 | Duplicate SKU, idempotency mismatch, insufficient stock |
| 500 | Unexpected failure — message is generic, never a stack trace |

## Products

```
GET    /api/v1/products
GET    /api/v1/products/{id}
POST   /api/v1/products
PUT    /api/v1/products/{id}
DELETE /api/v1/products/{id}
```

Query parameters on the collection:

- `category` — category slug
- `category_id` — numeric id
- `search` — case-insensitive match on title, description, brand
- `page` — default 1
- `limit` — default 12, max 50
- `min_price` / `max_price`
- `featured` — `true` \| `false`
- `fields` — comma-separated allow-list

Allowed fields: `id,title,slug,description,price,compare_at_price,stock,category_id,category,image_url,gallery,brand,sku,rating,review_count,featured,created_at,updated_at`.

## Orders

```
POST /api/v1/orders
Idempotency-Key: 8-to-128-character-key
```

Body:

```json
{
  "shipping_name": "Amina Shah",
  "shipping_address": "12 Clifton Block 5",
  "shipping_city": "Karachi",
  "shipping_phone": "+92 300 0000000",
  "items": [{ "product_id": 1, "quantity": 1 }]
}
```

Replaying the same key returns the original order and does not decrement stock twice.
